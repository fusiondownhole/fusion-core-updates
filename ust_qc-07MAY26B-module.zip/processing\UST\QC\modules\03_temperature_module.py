import numpy as np
import os

from base import BaseModule, ModuleResult
from h5_utils import first_available, to_float_array
from report_ui import draw_metric_row
from simulated_depth_export import (
    _detect_pressure_segments,
    _estimate_depth_per_rev_from_temp,
    _fit_depth_per_rev_from_reference,
    _load_combined_wdl_depth,
    _median_rev_rate,
)


def _warning_intervals_from_mask(x, mask, min_points=3):
    x = np.asarray(x, dtype=float)
    mask = np.asarray(mask, dtype=bool)[: x.size]
    intervals = []
    start = None
    for idx, flag in enumerate(mask):
        if flag and start is None:
            start = idx
        if start is not None and ((not flag) or idx == len(mask) - 1):
            end = idx - 1 if not flag else idx
            if end - start + 1 >= min_points:
                intervals.append(
                    {
                        "start_rev": float(x[start]),
                        "end_rev": float(x[end]),
                    }
                )
            start = None
    return intervals


class TemperatureModule(BaseModule):
    name = "Temperature"

    def __init__(
        self,
        temp_paths=None,
        rev_paths=None,
        timestamp_paths=None,
        pressure_paths=None,
        smooth_window=41,
        geothermal_gradient_f_per_ft=0.015,
        residual_limit_f=1.0,
        trim_fraction=0.05,
        aggregate_points=4,
    ):
        self.temp_paths = temp_paths or [
            "secondary_sensors/PT/temperature",
            "tool/sensor_board_temperature",
            "tool/main_board_temperature",
        ]
        self.rev_paths = rev_paths or [
            "secondary_sensors/PT/rev_number",
            "main_sensor/rev_number",
            "tool/rev_number",
        ]
        self.timestamp_paths = timestamp_paths or [
            "secondary_sensors/PT/timestamp",
            "main_sensor/timestamp",
            "tool/timestamp",
        ]
        self.pressure_paths = pressure_paths or [
            "secondary_sensors/PT/pressure",
            "pressure",
        ]
        self.smooth_window = int(smooth_window)
        self.geothermal_gradient_f_per_ft = float(geothermal_gradient_f_per_ft)
        self.residual_limit_f = float(residual_limit_f)
        self.trim_fraction = float(trim_fraction)
        self.aggregate_points = max(1, int(aggregate_points))

    def _smooth_edge(self, x, w):
        x = np.asarray(x, dtype=float)
        if w <= 1 or x.size == 0:
            return x.copy()
        w = max(1, min(int(w), x.size))
        if w == 1:
            return x.copy()
        pad_left = w // 2
        pad_right = w - 1 - pad_left
        xpad = np.pad(x, (pad_left, pad_right), mode="edge")
        return np.convolve(xpad, np.ones(w) / w, mode="valid")

    def _trimmed_slice(self, n):
        if n <= 2:
            return slice(0, n)
        k = int(max(0, min(n // 4, round(n * self.trim_fraction))))
        if 2 * k >= n - 2:
            k = max(0, (n - 2) // 2)
        return slice(k, n - k)

    def _fahrenheit(self, values_c):
        return np.asarray(values_c, dtype=float) * 9.0 / 5.0 + 32.0

    def _aggregate_series(self, x, y, t, npts):
        x = np.asarray(x, dtype=float)
        y = np.asarray(y, dtype=float)
        t = np.asarray(t, dtype=float)
        npts = max(1, int(npts))
        if npts <= 1 or x.size < npts:
            return x.copy(), y.copy(), t.copy()
        n = (x.size // npts) * npts
        if n < npts:
            return x.copy(), y.copy(), t.copy()
        xr = x[:n].reshape(-1, npts)
        yr = y[:n].reshape(-1, npts)
        tr = t[:n].reshape(-1, npts)
        xg = np.nanmean(xr, axis=1)
        yg = np.nanmean(yr, axis=1)
        tg = np.nanmean(tr, axis=1)
        if n < x.size:
            xg = np.concatenate([xg, [np.nanmean(x[n:])]])
            yg = np.concatenate([yg, [np.nanmean(y[n:])]])
            tg = np.concatenate([tg, [np.nanmean(t[n:])]])
        return xg, yg, tg

    def _nice_bound(self, x, direction="down"):
        if not np.isfinite(x):
            return float("nan")
        step = 1.0 if abs(x) >= 10 else 0.5
        if direction == "down":
            return np.floor(x / step) * step
        return np.ceil(x / step) * step

    def compute(self, h5):
        temp_path, temp_data = first_available(h5, self.temp_paths)
        rev_path, rev_data = first_available(h5, self.rev_paths)
        time_path, time_data = first_available(h5, self.timestamp_paths)
        pressure_path, pressure_data = first_available(h5, self.pressure_paths)

        if temp_data is None:
            return ModuleResult(
                name=self.name,
                status="ERROR",
                messages=["No temperature dataset found"],
                metrics={},
                plot_data={},
            )
        if rev_data is None:
            return ModuleResult(
                name=self.name,
                status="ERROR",
                messages=["No revolution number dataset found"],
                metrics={},
                plot_data={},
            )
        if time_data is None:
            return ModuleResult(
                name=self.name,
                status="ERROR",
                messages=["No timestamp dataset found"],
                metrics={},
                plot_data={},
            )

        temp_c = to_float_array(temp_data).reshape(-1)
        rev = to_float_array(rev_data).reshape(-1)
        ts = to_float_array(time_data).reshape(-1)
        pressure = to_float_array(pressure_data).reshape(-1) if pressure_data is not None else np.full_like(temp_c, np.nan)

        n = min(len(temp_c), len(rev), len(ts), len(pressure))
        temp_c = temp_c[:n]
        rev = rev[:n]
        ts = ts[:n]
        pressure = pressure[:n]

        valid = np.isfinite(temp_c) & np.isfinite(rev) & np.isfinite(ts)
        missing_count = int((~valid).sum())
        missing_pct = 100.0 * missing_count / max(1, n)

        if not np.any(valid):
            return ModuleResult(
                name=self.name,
                status="ERROR",
                messages=["No finite temperature samples after alignment"],
                metrics={},
                plot_data={},
            )

        temp_f = self._fahrenheit(temp_c[valid])
        temp_c = temp_c[valid]
        rev = rev[valid]
        ts = ts[valid]
        pressure = pressure[valid]

        order_ts = np.argsort(ts)
        temp_f = temp_f[order_ts]
        temp_c = temp_c[order_ts]
        rev = rev[order_ts]
        ts = ts[order_ts]
        pressure = pressure[order_ts]

        uniq_ts, uniq_idx_ts = np.unique(ts, return_index=True)
        temp_f = temp_f[uniq_idx_ts]
        temp_c = temp_c[uniq_idx_ts]
        rev = rev[uniq_idx_ts]
        pressure = pressure[uniq_idx_ts]
        ts = uniq_ts

        pressure_segments = _detect_pressure_segments(rev, pressure)
        pullup_segments = [segment for segment in pressure_segments if segment["trend"] == "pull-up"]

        order = np.argsort(rev)
        temp_f = temp_f[order]
        temp_c = temp_c[order]
        rev = rev[order]
        ts = ts[order]
        pressure = pressure[order]

        uniq_rev, uniq_idx = np.unique(rev, return_index=True)
        temp_f = temp_f[uniq_idx]
        temp_c = temp_c[uniq_idx]
        ts = ts[uniq_idx]
        pressure = pressure[uniq_idx]
        rev = uniq_rev

        if len(rev) < 3:
            return ModuleResult(
                name=self.name,
                status="ERROR",
                messages=["Temperature module needs at least 3 samples"],
                metrics={},
                plot_data={},
            )

        rev, temp_f, ts = self._aggregate_series(rev, temp_f, ts, self.aggregate_points)
        temp_c_ag = (temp_f - 32.0) * 5.0 / 9.0
        rel_ts_all = ts - ts[0]

        temp_s = self._smooth_edge(temp_f, self.smooth_window)
        fit_slice = self._trimmed_slice(len(rev))
        fit_rev = rev[fit_slice]
        fit_temp = temp_s[fit_slice]
        if len(fit_rev) < 2:
            fit_rev = rev
            fit_temp = temp_s

        slope_f_per_rev, _ = np.polyfit(fit_rev, fit_temp, 1)

        baseline_window = max(self.smooth_window * 8, 151)
        baseline_window = min(
            baseline_window,
            len(temp_f) if len(temp_f) % 2 == 1 else max(1, len(temp_f) - 1),
        )
        if baseline_window < 5:
            baseline_window = max(1, len(temp_f))
        temp_baseline = self._smooth_edge(temp_f, baseline_window)

        residual_f = temp_f - temp_baseline
        residual_center = float(np.nanmedian(residual_f)) if np.any(np.isfinite(residual_f)) else 0.0
        residual_f = residual_f - residual_center
        residual_s = self._smooth_edge(residual_f, self.smooth_window)

        dt = np.diff(ts)
        dr = np.diff(rev)
        good_rate = np.isfinite(dt) & np.isfinite(dr) & (dt > 0) & (dr > 0)

        rev_per_sec = float(np.nanmedian(dr[good_rate] / dt[good_rate])) if np.any(good_rate) else float("nan")

        if np.isfinite(slope_f_per_rev) and self.geothermal_gradient_f_per_ft > 0:
            depth_per_rev = abs(slope_f_per_rev) / self.geothermal_gradient_f_per_ft
        else:
            depth_per_rev = float("nan")

        speed_fpm = (
            depth_per_rev * rev_per_sec * 60.0
            if np.isfinite(depth_per_rev) and np.isfinite(rev_per_sec)
            else float("nan")
        )

        pass_speed_fpm = float("nan")
        pass_messages = []
        if pullup_segments:
            job_folder = os.environ.get("FUSION_JOB_FOLDER")
            wdl_info = _load_combined_wdl_depth(job_folder) if job_folder else None
            weighted_speed = 0.0
            total_duration = 0.0
            pass_details = []
            for segment in pullup_segments:
                start_rev = float(segment["start_rev"])
                end_rev = float(segment["end_rev"])
                seg_mask = (rev >= start_rev) & (rev <= end_rev)
                if np.count_nonzero(seg_mask) < 10:
                    continue
                rev_seg = rev[seg_mask]
                rel_ts_seg = rel_ts_all[seg_mask]
                temp_c_seg = temp_c_ag[seg_mask]
                depth_per_rev_seg = float("nan")
                overlap_count = 0
                if wdl_info is not None:
                    depth_per_rev_seg, overlap_count, _ = _fit_depth_per_rev_from_reference(
                        rel_ts_seg,
                        rev_seg,
                        wdl_info["time_s"],
                        wdl_info["depth_ft"],
                        surface_rev=float(rev_seg[-1]),
                    )
                if not (np.isfinite(depth_per_rev_seg) and depth_per_rev_seg > 0):
                    depth_per_rev_seg = _estimate_depth_per_rev_from_temp(rev_seg, temp_c_seg)

                rev_per_sec_seg = _median_rev_rate(rev_seg, rel_ts_seg)
                speed_seg = (
                    depth_per_rev_seg * rev_per_sec_seg * 60.0
                    if np.isfinite(depth_per_rev_seg) and np.isfinite(rev_per_sec_seg)
                    else float("nan")
                )
                duration_seg = float(rel_ts_seg[-1] - rel_ts_seg[0]) if rel_ts_seg.size > 1 else 0.0
                if np.isfinite(speed_seg) and duration_seg > 0:
                    weighted_speed += speed_seg * duration_seg
                    total_duration += duration_seg
                    pass_details.append((start_rev, end_rev, speed_seg, overlap_count))

            if total_duration > 0:
                pass_speed_fpm = weighted_speed / total_duration
                pass_messages.append(
                    f"Pressure trend detected {len(pullup_segments)} pull-up pass(es); weighted moving speed is ~{pass_speed_fpm:.1f} ft/min."
                )
                for idx, (start_rev, end_rev, speed_seg, overlap_count) in enumerate(pass_details, start=1):
                    detail = f"Pass {idx}: rev {start_rev:.0f}-{end_rev:.0f}, ~{speed_seg:.1f} ft/min"
                    if overlap_count:
                        detail += f" using {overlap_count} WDL-overlap samples"
                    pass_messages.append(detail + ".")

        display_speed_fpm = pass_speed_fpm if np.isfinite(pass_speed_fpm) else speed_fpm

        if np.isfinite(depth_per_rev):
            assumed_total_depth_ft = float((rev[-1] - rev[0]) * depth_per_rev)
        else:
            assumed_total_depth_ft = float("nan")

        min_temp_f = float(np.nanmin(temp_f))
        max_temp_f = float(np.nanmax(temp_f))
        p5 = float(np.nanpercentile(temp_f, 5))
        p95 = float(np.nanpercentile(temp_f, 95))
        span90 = p95 - p5
        total_span = span90 / 0.90 if span90 > 0 else 2.0
        pad = 0.05 * total_span
        lower_scale = self._nice_bound(min(p5 - pad, min_temp_f), direction="down")
        upper_scale = self._nice_bound(max(p95 + pad, max_temp_f), direction="up")

        residual_p95 = float(np.nanpercentile(np.abs(residual_s), 95)) if np.any(np.isfinite(residual_s)) else float("nan")

        delta_shade_mask = np.abs(residual_s) > self.residual_limit_f
        warning_intervals = _warning_intervals_from_mask(rev, delta_shade_mask, min_points=max(3, min(8, rev.size // 250)))

        status = "INFO"
        if warning_intervals:
            status = "WARN"
        if missing_pct > 1.0:
            status = "WARN"

        return ModuleResult(
            name=self.name,
            status=status,
            messages=[
                f"Temperature source: {temp_path}",
                f"Rev source: {rev_path}",
                f"Timestamp source: {time_path}",
                f"Pressure source: {pressure_path}" if pressure_path else "Pressure source unavailable for pass detection",
                f"Estimated logging speed: {display_speed_fpm:.1f} ft/min" if np.isfinite(display_speed_fpm) else "Estimated logging speed unavailable",
                f"Geothermal gradient assumption: {self.geothermal_gradient_f_per_ft * 100.0:.2f} F/100 ft",
                f"Displayed trace averaged over {self.aggregate_points} sample(s)",
                f"Residual P95: {residual_p95:.2f} F" if np.isfinite(residual_p95) else "Residual P95 unavailable",
                f"Estimated total depth: {assumed_total_depth_ft:.1f} ft" if np.isfinite(assumed_total_depth_ft) else "Estimated total depth unavailable",
                *[
                    f"Temperature warning interval: rev {interval['start_rev']:.0f}-{interval['end_rev']:.0f}"
                    for interval in warning_intervals[:4]
                ],
                *pass_messages,
            ],
            metrics={
                "Max Temp": (max_temp_f, "INFO", "degF"),
                "Lower Scale": (lower_scale, "INFO", "degF"),
                "Upper Scale": (upper_scale, "INFO", "degF"),
                "Log Speed": (
                    display_speed_fpm,
                    "PASS" if np.isfinite(display_speed_fpm) and display_speed_fpm < 25.0 else "WARN" if np.isfinite(display_speed_fpm) and display_speed_fpm < 35.0 else "FAIL" if np.isfinite(display_speed_fpm) else "INFO",
                    "FPM",
                ),
            },
            plot_data={
                "x": rev,
                "residual_f": residual_s,
                "delta_shade_mask": delta_shade_mask,
                "warning_intervals": warning_intervals,
                "axis_label": "Revolution #",
                "residual_limit_f": self.residual_limit_f,
                "speed_fpm": display_speed_fpm,
                "depth_per_rev": depth_per_rev,
                "fit_slope_f_per_rev": slope_f_per_rev,
                "temp_f": temp_f,
                "expected_f": temp_baseline + residual_center,
                "baseline_f": temp_baseline,
                "assumed_total_depth_ft": assumed_total_depth_ft,
                "residual_center_f": residual_center,
                "timestamp_s": ts,
                "pullup_pass_count": len(pullup_segments),
            },
        )

    def draw(self, fig, left, bottom, width, height, result: ModuleResult):
        header_h = height * 0.10
        plot_zone_h = height * 0.55
        xband_h = height * 0.05
        box_zone_h = height * 0.30
        pad_left = width * 0.075
        pad_right = width * 0.055
        inner_left = left + pad_left
        inner_width = width - pad_left - pad_right
        title_y = bottom + height - header_h * 0.58
        plot_bottom = bottom + box_zone_h + xband_h + height * 0.025
        plot_h = plot_zone_h - height * 0.055
        boxes_bottom = bottom + height * 0.035
        boxes_h = box_zone_h - height * 0.09

        fig.text(
            inner_left,
            title_y,
            "Temperature",
            fontsize=16,
            fontweight="bold",
            ha="left",
            va="center",
            color="#1f2937",
        )

        if result.status == "ERROR" or not result.plot_data:
            ax = fig.add_axes(
                [inner_left, bottom + box_zone_h + 0.04 * height, inner_width, plot_zone_h + xband_h - 0.08 * height],
                facecolor="#f7f7f7",
            )
            ax.set_axis_off()
            ax.text(
                0.5,
                0.58,
                "Temperature data unavailable",
                ha="center",
                va="center",
                fontsize=16,
                fontweight="bold",
                color="#6b7280",
            )
            msg = "\n".join(result.messages[:3]) if result.messages else "No details"
            ax.text(0.5, 0.32, msg, ha="center", va="center", fontsize=10, color="#6b7280")
            return

        ax = fig.add_axes([inner_left, plot_bottom, inner_width, plot_h], facecolor="white")
        x = np.asarray(result.plot_data.get("x", []), dtype=float)
        temp = np.asarray(result.plot_data.get("temp_f", []), dtype=float)
        delta = np.asarray(result.plot_data.get("residual_f", []), dtype=float)
        valid_temp = np.isfinite(x) & np.isfinite(temp)

        ax.plot(x[valid_temp], temp[valid_temp], linewidth=1.0, color="#2563eb")
        lo = float(np.nanpercentile(temp[valid_temp], 5)) if np.any(valid_temp) else 0.0
        hi = float(np.nanpercentile(temp[valid_temp], 95)) if np.any(valid_temp) else 1.0
        pad = max((hi - lo) * 0.08, 0.5)
        ax.set_ylim(lo - pad, hi + pad)
        ax.set_ylabel("Temperature (degF)", fontsize=10.5, color="#2563eb")
        ax.tick_params(axis="y", labelsize=8.5, colors="#2563eb", pad=2)
        ax.tick_params(axis="x", labelsize=8.5, colors="#111827", pad=2)
        ax.spines["left"].set_color("#2563eb")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

        valid_delta = np.isfinite(x) & np.isfinite(delta)
        if np.any(valid_delta):
            ax2 = ax.twinx()
            delta_shade_mask = np.asarray(result.plot_data.get("delta_shade_mask", []), dtype=bool)
            delta_shade_mask = delta_shade_mask[:len(x)]
            start = None
            for i, flag in enumerate(valid_delta & delta_shade_mask):
                if flag and start is None:
                    start = i
                if start is not None and ((not flag) or i == len(valid_delta) - 1):
                    end = i if not flag else i + 1
                    if end - start >= 1:
                        ax.axvspan(x[start], x[end - 1], color="#efe3a6", alpha=0.35, zorder=0)
                    start = None

            ax2.plot(x[valid_delta], delta[valid_delta], linewidth=1.2, color="#d94841", linestyle="--", alpha=0.95)
            lim = float(np.nanmax(np.abs(delta[valid_delta])))
            lim = max(lim * 1.10, 1.1)
            ax2.set_ylim(-lim, lim)
            ax2.set_ylabel("Delta Temp (degF)", fontsize=10.5, color="#d94841", labelpad=10)
            ax2.tick_params(axis="y", labelsize=8.5, colors="#d94841", pad=2)
            ax2.axhline(0.0, linestyle=":", linewidth=0.9, color="#d94841", alpha=0.75)
            ax2.axhline(-1.0, linestyle=":", linewidth=0.8, color="#d94841", alpha=0.75)
            ax2.axhline(1.0, linestyle=":", linewidth=0.8, color="#d94841", alpha=0.75)
            ax2.spines["top"].set_visible(False)
            ax2.spines["right"].set_color("#d94841")

        labels = list(result.metrics.keys())
        values = []
        statuses = []
        for k in labels:
            v, s, units = result.metrics[k]
            values.append(f"{v:.1f} {units}" if np.isfinite(v) else "n/a")
            statuses.append(s)

        draw_metric_row(
            fig,
            left=inner_left,
            bottom=boxes_bottom,
            width=inner_width,
            height=boxes_h,
            labels=labels,
            values=values,
            statuses=statuses,
            gap_fraction=0.014,
            edgecolor="#9aa0a6",
            linewidth=1.0,
            value_fontsize=10.2,
            label_fontsize=8.5,
            value_fontweight="bold",
            label_fontweight="bold",
            text_color="#1f2937",
            label_color="#374151",
            show_markers=True,
            marker_radius=0.016,
            marker_color="#000000",
        )
