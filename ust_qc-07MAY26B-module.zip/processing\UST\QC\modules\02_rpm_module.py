import numpy as np

from base import BaseModule, ModuleResult
from h5_utils import first_available, get_units, to_float_array
from report_ui import draw_metric_row


class RPMModule(BaseModule):
    name = "RPM"

    def __init__(
        self,
        rpm_target=160.0,
        rpm_tol=1.0,
        rpm_ylim=(158.0, 162.0),
        rpm_smooth=11,
        torque_smooth=101,
        rolling_window=150,
        trim_samples=5,
        stall_torque=60.0,
    ):
        self.rpm_target = float(rpm_target)
        self.rpm_tol = float(rpm_tol)
        self.rpm_ylim = rpm_ylim
        self.rpm_smooth = int(rpm_smooth)
        self.torque_smooth = int(torque_smooth)
        self.rolling_window = int(rolling_window)
        self.trim_samples = int(trim_samples)
        self.stall_torque = float(stall_torque)
        self.rpm_paths = [
            "tool/rotating_head_speed",
            "tool/rpm",
            "rotating_head_speed",
            "rpm",
            "rotating_speed",
        ]
        self.rev_paths = [
            "tool/rev_number",
            "main_sensor/rev_number",
            "secondary_sensors/PT/rev_number",
            "secondary_sensors/TOF/rev_number",
            "rev_number",
        ]
        self.time_paths = [
            "tool/timestamp",
            "main_sensor/timestamp",
            "secondary_sensors/PT/timestamp",
            "secondary_sensors/TOF/timestamp",
            "timestamp",
        ]
        self.torque_paths = ["tool/motor_torque", "tool/torque", "motor_torque", "torque"]

    def _smooth_edge(self, x, w):
        x = np.asarray(x, dtype=float)
        if w <= 1 or len(x) == 0:
            return x.copy()
        w = min(int(w), len(x))
        pad_left = w // 2
        pad_right = w - 1 - pad_left
        xpad = np.pad(x, (pad_left, pad_right), mode="edge")
        return np.convolve(xpad, np.ones(w) / w, mode="valid")

    def _rolling_std_series(self, x, w):
        x = np.asarray(x, dtype=float)
        if x.size == 0:
            return np.array([], dtype=float)
        w = max(3, min(int(w), len(x)))
        if w >= len(x):
            return np.full_like(x, np.nanstd(x))
        c1 = np.cumsum(np.insert(x, 0, 0.0))
        c2 = np.cumsum(np.insert(x * x, 0, 0.0))
        sw = c1[w:] - c1[:-w]
        s2w = c2[w:] - c2[:-w]
        mw = sw / w
        vw = np.maximum(s2w / w - mw * mw, 0.0)
        out = np.sqrt(vw)
        pad_left = w // 2
        pad_right = x.size - out.size - pad_left
        return np.pad(out, (pad_left, pad_right), mode="edge")

    def _metric_status_avg(self, v):
        d = abs(v - self.rpm_target)
        return "PASS" if d <= 0.5 else "WARN" if d <= 1.0 else "FAIL"

    def _metric_status_tolerance(self, v):
        return "PASS" if v >= 98.5 else "WARN" if v >= 97.5 else "FAIL"

    def _metric_status_gap(self, v_sec):
        return "PASS" if v_sec <= 3.5 else "WARN" if v_sec <= 8.0 else "FAIL"

    def _metric_status_stability(self, v):
        return "PASS" if v <= 0.40 else "WARN" if v <= 0.70 else "FAIL"

    def _metric_status_p2p(self, v):
        return "PASS" if v <= 1.5 else "WARN" if v <= 2.5 else "FAIL"

    def _derive_rpm_from_rev_time(self, h5):
        rev_path, rev_data = first_available(h5, self.rev_paths)
        time_path, time_data = first_available(h5, self.time_paths)
        if rev_data is None or time_data is None:
            return None
        rev = to_float_array(rev_data).reshape(-1)
        t = to_float_array(time_data).reshape(-1)
        n = min(rev.size, t.size)
        if n < 2:
            return None
        rev = rev[:n]
        t = t[:n]
        valid = np.isfinite(rev) & np.isfinite(t)
        rev = rev[valid]
        t = t[valid]
        if rev.size < 2:
            return None
        order = np.argsort(t)
        rev = rev[order]
        t = t[order]
        dt = np.diff(t)
        dr = np.diff(rev)
        ok = np.isfinite(dt) & np.isfinite(dr) & (dt > 0) & (dr >= 0)
        if not np.any(ok):
            return None
        rpm = 60.0 * dr[ok] / dt[ok]
        x = rev[1:][ok]
        t_mid = 0.5 * (t[1:][ok] + t[:-1][ok])
        return {"rpm_raw": rpm, "x_full": x, "t_full": t_mid, "source": f"derived from {rev_path} and {time_path}"}

    def _extract_intervals(self, mask, x):
        mask = np.asarray(mask, dtype=bool)
        x = np.asarray(x, dtype=float)
        intervals = []
        start = None
        for i, flag in enumerate(mask):
            if flag and start is None:
                start = i
            if start is not None and ((not flag) or i == len(mask) - 1):
                end = i if not flag else i + 1
                if end - start >= 1:
                    intervals.append((x[start], x[end - 1]))
                start = None
        return intervals

    def _clip_edges(self, arr):
        arr = np.asarray(arr)
        if arr.size <= 2 * self.trim_samples:
            return arr.copy()
        return arr[self.trim_samples:-self.trim_samples]

    def compute(self, h5):
        rpm_path, rpm_data = first_available(h5, self.rpm_paths)
        x_path, x_data = first_available(h5, self.rev_paths)
        t_path, t_data = first_available(h5, self.time_paths)

        source_desc = None
        x_full = None
        t_full = None

        if rpm_data is not None:
            rpm_raw = to_float_array(rpm_data).reshape(-1)
            source_desc = rpm_path
            if x_data is not None:
                x_arr = to_float_array(x_data).reshape(-1)
            else:
                x_arr = np.arange(rpm_raw.size, dtype=float)
            if t_data is not None:
                t_arr = to_float_array(t_data).reshape(-1)
            else:
                t_arr = np.arange(rpm_raw.size, dtype=float)
            n = min(rpm_raw.size, x_arr.size, t_arr.size)
            rpm_raw = rpm_raw[:n]
            x_full = x_arr[:n]
            t_full = t_arr[:n]
        else:
            derived = self._derive_rpm_from_rev_time(h5)
            if derived is None:
                return ModuleResult(
                    name=self.name,
                    status="ERROR",
                    messages=["Missing RPM dataset and could not derive from rev/timestamp"],
                    metrics={},
                    plot_data={},
                )
            rpm_raw = derived["rpm_raw"]
            x_full = derived["x_full"]
            t_full = derived["t_full"]
            source_desc = derived["source"]

        if rpm_raw.size == 0:
            return ModuleResult(name=self.name, status="ERROR", messages=["RPM dataset empty"], metrics={}, plot_data={})

        valid_mask = np.isfinite(rpm_raw) & np.isfinite(x_full) & np.isfinite(t_full)
        missing_count = int((~valid_mask).sum())
        missing_pct = 100.0 * missing_count / rpm_raw.size
        rpm_valid = rpm_raw[valid_mask]
        x_valid = x_full[valid_mask]
        t_valid = t_full[valid_mask]
        if rpm_valid.size == 0:
            return ModuleResult(name=self.name, status="ERROR", messages=["RPM dataset contains no finite samples"], metrics={}, plot_data={})

        rpm_eval = self._clip_edges(rpm_valid)
        x_eval = self._clip_edges(x_valid)
        t_eval = self._clip_edges(t_valid)
        if rpm_eval.size == 0:
            rpm_eval, x_eval, t_eval = rpm_valid, x_valid, t_valid

        avg = float(np.mean(rpm_eval))
        in_tol = np.abs(rpm_eval - self.rpm_target) <= self.rpm_tol
        tolerance = float(np.mean(in_tol) * 100.0)

        out = np.abs(rpm_eval - self.rpm_target) > self.rpm_tol
        max_gap_s = 0.0
        start_idx = None
        for i, flag in enumerate(out):
            if flag and start_idx is None:
                start_idx = i
            if start_idx is not None and ((not flag) or i == len(out) - 1):
                end_idx = i if not flag else i
                if end_idx >= start_idx:
                    max_gap_s = max(max_gap_s, float(t_eval[end_idx] - t_eval[start_idx]))
                start_idx = None

        rpm_s_eval = self._smooth_edge(rpm_eval, self.rpm_smooth)
        rpm_std_series = self._rolling_std_series(rpm_s_eval, self.rolling_window)
        stability = float(np.nanpercentile(rpm_std_series, 95)) if rpm_std_series.size else float(np.std(rpm_s_eval))
        p2p = float(np.max(rpm_s_eval) - np.min(rpm_s_eval))

        metric_statuses = [
            self._metric_status_avg(avg),
            self._metric_status_tolerance(tolerance),
            self._metric_status_gap(max_gap_s),
            self._metric_status_stability(stability),
            self._metric_status_p2p(p2p),
        ]
        status = "PASS"
        if "FAIL" in metric_statuses:
            status = "FAIL"
        elif "WARN" in metric_statuses:
            status = "WARN"
        if missing_pct > 1.0:
            status = "ERROR"
        elif missing_pct >= 0.1 and status == "PASS":
            status = "WARN"

        rpm_s = self._smooth_edge(rpm_valid, self.rpm_smooth)

        torque_path, torque_data = first_available(h5, self.torque_paths)
        torque_s = None
        torque_units = ""
        stall_marker = None
        torque_x = None
        if torque_data is not None:
            tq = to_float_array(torque_data).reshape(-1)
            torque_units = get_units(h5, torque_path, default="")
            n = min(len(tq), len(x_full))
            tq = tq[:n]
            tq_mask = np.isfinite(tq)
            tq_valid = tq[tq_mask]
            if tq_valid.size > 0:
                torque_s = self._smooth_edge(tq_valid, self.torque_smooth)
                tq_x = x_full[:n][tq_mask]
                torque_x = tq_x[:len(torque_s)]

        if self.stall_torque is not None:
            stall_marker = 0.75 * float(self.stall_torque)

        shade_mask = np.abs(rpm_s - self.rpm_target) > self.rpm_tol
        warning_intervals = [
            {"start_rev": float(x0), "end_rev": float(x1)}
            for x0, x1 in self._extract_intervals(shade_mask, x_valid)
        ]

        return ModuleResult(
            name=self.name,
            status=status,
            messages=[
                f"Samples: {rpm_raw.size}",
                f"Missing: {missing_count} ({missing_pct:.3f}%)",
                f"RPM source: {source_desc}",
                "Max Gap is the longest continuous time outside the +/- RPM tolerance band.",
                "Stability uses P95 rolling RPM stdev so it reflects the majority of the well.",
            ],
            metrics={
                "AVG": (avg, self._metric_status_avg(avg), "RPM"),
                "Tolerance": (tolerance, self._metric_status_tolerance(tolerance), "%"),
                "Max Gap": (max_gap_s, self._metric_status_gap(max_gap_s), "s"),
                "Stability": (stability, self._metric_status_stability(stability), "RPM"),
                "P2P RPM": (p2p, self._metric_status_p2p(p2p), "RPM"),
            },
            plot_data={
                "x": x_valid,
                "rpm": rpm_s,
                "torque_x": torque_x,
                "torque": torque_s,
                "torque_units": torque_units,
                "stall_marker": stall_marker,
                "shade_mask": shade_mask,
                "warning_intervals": warning_intervals,
            },
        )

    def draw(self, fig, left, bottom, width, height, result: ModuleResult):
        header_h = height * 0.10
        plot_zone_h = height * 0.55
        xband_h = height * 0.05
        box_zone_h = height * 0.30
        pad_left = width * 0.075
        pad_right = width * 0.055
        inner_left = left + pad_left
        inner_width = width - pad_left - pad_right
        title_y = bottom + height - header_h * 0.58
        plot_bottom = bottom + box_zone_h + xband_h + height * 0.025
        plot_h = plot_zone_h - height * 0.055
        boxes_bottom = bottom + height * 0.035
        boxes_h = box_zone_h - height * 0.09

        fig.text(inner_left, title_y, "RPM", fontsize=16, fontweight="bold", ha="left", va="center", color="#1f2937")
        fig.text(inner_left + inner_width, title_y, f"Target {int(self.rpm_target)} +/- {int(self.rpm_tol)} RPM", fontsize=10, ha="right", va="center", color="#4b5563")

        if result.status == "ERROR" or not result.plot_data:
            ax = fig.add_axes(
                [inner_left, bottom + box_zone_h + 0.04 * height, inner_width, plot_zone_h + xband_h - 0.08 * height],
                facecolor="#f7f7f7",
            )
            ax.set_axis_off()
            ax.text(0.5, 0.58, "RPM data unavailable", ha="center", va="center", fontsize=16, fontweight="bold", color="#6b7280")
            msg = "\n".join(result.messages[:3]) if result.messages else "No details"
            ax.text(0.5, 0.32, msg, ha="center", va="center", fontsize=10, color="#6b7280")
            return

        ax = fig.add_axes([inner_left, plot_bottom, inner_width, plot_h], facecolor="white")
        x = np.asarray(result.plot_data.get("x", []), dtype=float)
        rpm = np.asarray(result.plot_data.get("rpm", []), dtype=float)
        valid = np.isfinite(x) & np.isfinite(rpm)
        shade_mask = np.asarray(result.plot_data.get("shade_mask", []), dtype=bool)
        if np.any(valid):
            shade_mask = shade_mask[:len(x)]
            for x0, x1 in self._extract_intervals(valid & shade_mask, x):
                ax.axvspan(x0, x1, color="#efe3a6", alpha=0.35, zorder=0)
            ax.plot(x[valid], rpm[valid], linewidth=1.0, color="#4c6ef5")
        ax.set_ylim(*self.rpm_ylim)
        ax.set_ylabel("RPM", fontsize=10.5, color="#2563eb")
        ax.axhline(self.rpm_target, linestyle="--", linewidth=1.0, color="#555555")
        ax.axhline(self.rpm_target - self.rpm_tol, linestyle=":", linewidth=0.8, color="#2563eb", alpha=0.85)
        ax.axhline(self.rpm_target + self.rpm_tol, linestyle=":", linewidth=0.8, color="#2563eb", alpha=0.85)
        ax.spines["top"].set_visible(False)
        ax.tick_params(axis="y", labelsize=8.5, colors="#2563eb", pad=2)
        ax.tick_params(axis="x", labelsize=8.5, colors="#111827", pad=2)
        ax.spines["left"].set_color("#2563eb")

        torque = result.plot_data.get("torque")
        if torque is not None and len(torque) > 0:
            torque_x = np.asarray(result.plot_data.get("torque_x", []), dtype=float)
            torque = np.asarray(torque, dtype=float)
            valid_t = np.isfinite(torque_x) & np.isfinite(torque)
            if np.any(valid_t):
                ax2 = ax.twinx()
                ax2.plot(torque_x[valid_t], torque[valid_t], color="#d94841", linewidth=1.55, linestyle="--", alpha=0.95)
                ymin = -10.0
                torque_peak = float(np.nanmax(torque[valid_t]))
                # Keep very low torque visible without offsetting the data itself.
                min_visible_upper = 5.0
                ymax = max(min_visible_upper, torque_peak * 1.25)
                stall_marker = result.plot_data.get("stall_marker")
                if stall_marker is not None:
                    ymax = max(ymax, float(stall_marker) * 1.15)
                    ax2.axhline(float(stall_marker), color="#d94841", linewidth=0.85, linestyle=":", alpha=0.8)
                ymax = min(80.0, ymax)
                ymax = max(ymax, 10.0)
                if ymax <= ymin:
                    ymax = ymin + 1.0
                ax2.set_ylim(ymin, ymax)
                units = result.plot_data.get("torque_units") or ""
                ax2.set_ylabel(f"Torque ({units})" if units else "Torque", fontsize=10.5, color="#d94841", labelpad=10)
                ax2.tick_params(axis="y", labelsize=8.5, colors="#d94841", pad=2)
                ax2.spines["top"].set_visible(False)
                ax2.spines["right"].set_color("#d94841")

        labels = list(result.metrics.keys())
        values = []
        statuses = []
        for k in labels:
            v, s, units = result.metrics[k]
            if k == "AVG":
                values.append(f"{v:.1f} {units}")
            elif k == "Tolerance":
                values.append(f"{v:.2f}{units}")
            elif k in ["Stability", "P2P RPM"]:
                values.append(f"{v:.3f} {units}")
            elif k == "Max Gap":
                values.append(f"{v:.1f} {units}")
            else:
                values.append(f"{int(v)} {units}")
            statuses.append(s)

        draw_metric_row(
            fig,
            left=inner_left,
            bottom=boxes_bottom,
            width=inner_width,
            height=boxes_h,
            labels=labels,
            values=values,
            statuses=statuses,
            gap_fraction=0.014,
            edgecolor="#9aa0a6",
            linewidth=1.0,
            value_fontsize=10.2,
            label_fontsize=8.5,
            value_fontweight="bold",
            label_fontweight="bold",
            text_color="#1f2937",
            label_color="#374151",
            show_markers=True,
            marker_radius=0.016,
            marker_color="#000000",
        )
