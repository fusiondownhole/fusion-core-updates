import numpy as np

from base import BaseModule, ModuleResult
from h5_utils import has_dataset, get_dataset, first_available, to_float_array
from report_ui import draw_metric_row


class IMUModule(BaseModule):
    name = "Accelerometer"

    def __init__(
        self,
        accel_path="secondary_sensors/IMU/inertial/acceleration",
        timestamp_path="secondary_sensors/IMU/device/timestamp",
        main_timestamp_paths=None,
        main_rev_paths=None,
        plot_smooth=31,
        shock_warn_g=3.0,
        shock_fail_g=5.0,
        rad_rms_warn_g=1.0,
        rad_rms_fail_g=2.0,
        ax_rms_warn_g=1.0,
        ax_rms_fail_g=2.0,
        decent_p95_warn_in=0.080,
        decent_p95_fail_in=0.150,
        logging_speed_fpm=30.0,
        joint_length_ft=40.0,
    ):
        self.accel_path = accel_path
        self.timestamp_path = timestamp_path
        self.main_timestamp_paths = main_timestamp_paths or [
            "main_sensor/timestamp",
            "secondary_sensors/PT/timestamp",
            "secondary_sensors/TOF/timestamp",
            "tool/timestamp",
        ]
        self.main_rev_paths = main_rev_paths or [
            "main_sensor/rev_number",
            "secondary_sensors/PT/rev_number",
            "secondary_sensors/TOF/rev_number",
            "tool/rev_number",
        ]
        self.plot_smooth = plot_smooth
        self.shock_warn_g = shock_warn_g
        self.shock_fail_g = shock_fail_g
        self.rad_rms_warn_g = rad_rms_warn_g
        self.rad_rms_fail_g = rad_rms_fail_g
        self.ax_rms_warn_g = ax_rms_warn_g
        self.ax_rms_fail_g = ax_rms_fail_g
        self.decent_p95_warn_in = decent_p95_warn_in
        self.decent_p95_fail_in = decent_p95_fail_in
        self.logging_speed_fpm = float(logging_speed_fpm)
        self.joint_length_ft = float(joint_length_ft)

    def _smooth_edge(self, x, w):
        x = np.asarray(x, dtype=float)
        if w <= 1 or x.size == 0:
            return x.copy()
        w = min(int(w), x.size)
        pad_left = w // 2
        pad_right = w - 1 - pad_left
        xpad = np.pad(x, (pad_left, pad_right), mode="edge")
        return np.convolve(xpad, np.ones(w) / w, mode="valid")

    def _status_low_good(self, value, warn, fail):
        if not np.isfinite(value):
            return "ERROR"
        if value <= warn:
            return "PASS"
        if value <= fail:
            return "WARN"
        return "FAIL"

    def _reshape_accel(self, accel, timestamps):
        accel = np.asarray(accel, dtype=float)
        timestamps = np.asarray(timestamps, dtype=float).reshape(-1)
        if accel.ndim != 2 or accel.shape[1] != 3:
            raise ValueError("Acceleration dataset must have shape [N, 3]")
        if timestamps.size == 0:
            raise ValueError("Timestamp dataset empty")
        if accel.shape[0] % timestamps.size != 0:
            raise ValueError("Acceleration sample count is not an integer multiple of timestamp count")
        samples_per_tick = accel.shape[0] // timestamps.size
        return accel.reshape(timestamps.size, samples_per_tick, 3), samples_per_tick

    def _interp_rpm(self, main_t, main_rev, target_t):
        main_t = np.asarray(main_t, dtype=float).reshape(-1)
        main_rev = np.asarray(main_rev, dtype=float).reshape(-1)
        valid = np.isfinite(main_t) & np.isfinite(main_rev)
        if np.sum(valid) < 2:
            return np.full_like(target_t, np.nan, dtype=float), float("nan")
        main_t = main_t[valid]
        main_rev = main_rev[valid]
        order = np.argsort(main_t)
        main_t = main_t[order]
        main_rev = main_rev[order]
        dt = np.diff(main_t)
        dr = np.diff(main_rev)
        ok = np.isfinite(dt) & np.isfinite(dr) & (dt > 0)
        if not np.any(ok):
            return np.full_like(target_t, np.nan, dtype=float), float("nan")
        rpm_mid = 60.0 * dr[ok] / dt[ok]
        t_mid = 0.5 * (main_t[1:][ok] + main_t[:-1][ok])
        rpm = np.interp(target_t, t_mid, rpm_mid, left=np.nan, right=np.nan)
        return rpm, float(np.nanmedian(rpm_mid))

    def _format_metric(self, value, units, decimals=3):
        if not np.isfinite(value):
            return "n/a"
        return f"{value:.{decimals}f} {units}" if units else f"{value:.{decimals}f}"

    def _max_spin_rate_window(self, unwrapped_deg, t):
        unwrapped_deg = np.asarray(unwrapped_deg, dtype=float)
        t = np.asarray(t, dtype=float)
        valid = np.isfinite(unwrapped_deg) & np.isfinite(t)
        if np.sum(valid) < 2:
            return float("nan"), float("nan"), float("nan")
        angle = unwrapped_deg[valid]
        ts = t[valid]
        order = np.argsort(ts)
        angle = angle[order]
        ts = ts[order]
        joint_time_s = self.joint_length_ft / (self.logging_speed_fpm / 60.0) if self.logging_speed_fpm > 0 else float("nan")
        if not np.isfinite(joint_time_s) or joint_time_s <= 0:
            return float("nan"), float("nan"), float("nan")
        n = len(ts)
        j = 0
        best_rate = float("nan")
        best_start = float("nan")
        best_end = float("nan")
        for i in range(n - 1):
            while j + 1 < n and ts[j + 1] - ts[i] <= joint_time_s:
                j += 1
            if j <= i:
                continue
            dt = ts[j] - ts[i]
            if dt <= 0:
                continue
            travel_deg = abs(angle[j] - angle[i])
            rate = (travel_deg / 360.0) / dt
            if not np.isfinite(best_rate) or rate > best_rate:
                best_rate = float(rate)
                best_start = float(ts[i])
                best_end = float(ts[j])
        return best_rate, best_start, best_end

    def compute(self, h5):
        if not has_dataset(h5, self.accel_path):
            return ModuleResult(name=self.name, status="ERROR", messages=[f"Missing dataset: {self.accel_path}"], metrics={}, plot_data={})
        if not has_dataset(h5, self.timestamp_path):
            return ModuleResult(name=self.name, status="ERROR", messages=[f"Missing dataset: {self.timestamp_path}"], metrics={}, plot_data={})

        accel = to_float_array(get_dataset(h5, self.accel_path))
        timestamps = to_float_array(get_dataset(h5, self.timestamp_path)).reshape(-1)
        if accel.size == 0 or timestamps.size == 0:
            return ModuleResult(name=self.name, status="ERROR", messages=["IMU datasets found but contain zero samples"], metrics={}, plot_data={})

        try:
            accel_blocks, samples_per_tick = self._reshape_accel(accel, timestamps)
        except Exception as exc:
            return ModuleResult(name=self.name, status="ERROR", messages=[str(exc)], metrics={}, plot_data={})

        valid_time = np.isfinite(timestamps)
        valid_accel = np.all(np.isfinite(accel_blocks), axis=(1, 2))
        valid_mask = valid_time & valid_accel
        missing_count = int((~valid_mask).sum())
        missing_pct = 100.0 * missing_count / timestamps.size
        if not np.any(valid_mask):
            return ModuleResult(name=self.name, status="ERROR", messages=["No finite IMU blocks"], metrics={}, plot_data={})

        t = timestamps[valid_mask]
        blocks = accel_blocks[valid_mask]

        dt = np.diff(t)
        dt = dt[np.isfinite(dt) & (dt > 0)]
        if dt.size == 0:
            return ModuleResult(name=self.name, status="ERROR", messages=["Cannot determine IMU sample rate"], metrics={}, plot_data={})
        tick_rate_hz = 1.0 / float(np.median(dt))
        sample_rate_hz = tick_rate_hz * samples_per_tick

        block_mean = np.mean(blocks, axis=1)
        dyn = blocks - block_mean[:, None, :]

        radial_dyn = np.sqrt(dyn[:, :, 0] ** 2 + dyn[:, :, 1] ** 2)
        axial_dyn = dyn[:, :, 2]
        total_dyn = np.sqrt(np.sum(dyn ** 2, axis=2))

        rad_rms_series = np.sqrt(np.mean(radial_dyn ** 2, axis=1))
        ax_rms_series = np.sqrt(np.mean(axial_dyn ** 2, axis=1))
        peak_shock_series = np.max(np.sqrt(np.sum(blocks ** 2, axis=2)), axis=1)

        rad_rms = float(np.nanmedian(rad_rms_series))
        ax_rms = float(np.nanmedian(ax_rms_series))
        peak_shock = float(np.nanmax(peak_shock_series))

        axis_label = "Timestamp (s)"
        x = t - t[0]
        main_t_path, main_t = first_available(h5, self.main_timestamp_paths)
        main_rev_path, main_rev = first_available(h5, self.main_rev_paths)
        ref_rpm_series = np.full_like(t, np.nan, dtype=float)
        ref_rpm = float("nan")
        if main_t is not None and main_rev is not None:
            main_t = to_float_array(main_t).reshape(-1)
            main_rev = to_float_array(main_rev).reshape(-1)
            ref_rpm_series, ref_rpm = self._interp_rpm(main_t, main_rev, t)
            valid_main = np.isfinite(main_t) & np.isfinite(main_rev)
            if np.sum(valid_main) >= 2:
                main_t = main_t[valid_main]
                main_rev = main_rev[valid_main]
                order = np.argsort(main_t)
                main_t = main_t[order]
                main_rev = main_rev[order]
                interp_ok = (t >= main_t[0]) & (t <= main_t[-1])
                if np.any(interp_ok):
                    x = np.full_like(t, np.nan, dtype=float)
                    x[interp_ok] = np.interp(t[interp_ok], main_t, main_rev)
                    axis_label = "Revolution #"

        omega = 2.0 * np.pi * ref_rpm_series / 60.0
        omega2 = omega ** 2
        decent_series = np.full_like(rad_rms_series, np.nan, dtype=float)
        good_omega = np.isfinite(omega2) & (omega2 > 1e-12)
        decent_series[good_omega] = (rad_rms_series[good_omega] * 386.0886) / omega2[good_omega]
        decent_p95 = float(np.nanpercentile(decent_series, 95)) if np.any(np.isfinite(decent_series)) else float("nan")

        gvec = block_mean.copy()
        gxy_angle = np.degrees(np.arctan2(gvec[:, 1], gvec[:, 0]))
        gxy_unwrapped = np.degrees(np.unwrap(np.radians(gxy_angle))) if gxy_angle.size else np.array([], dtype=float)
        max_spin_rate_rev_s, spin_win_start, spin_win_end = self._max_spin_rate_window(gxy_unwrapped, t)
        max_rev_40 = float(max_spin_rate_rev_s * (self.joint_length_ft / (self.logging_speed_fpm / 60.0))) if np.isfinite(max_spin_rate_rev_s) else float("nan")

        metric_statuses = [
            self._status_low_good(rad_rms, self.rad_rms_warn_g, self.rad_rms_fail_g),
            self._status_low_good(ax_rms, self.ax_rms_warn_g, self.ax_rms_fail_g),
            self._status_low_good(peak_shock, self.shock_warn_g, self.shock_fail_g),
            self._status_low_good(decent_p95, self.decent_p95_warn_in, self.decent_p95_fail_in),
            "INFO",
        ]
        status = "PASS"
        if "FAIL" in metric_statuses:
            status = "FAIL"
        elif "WARN" in metric_statuses:
            status = "WARN"
        if missing_pct > 1.0:
            status = "ERROR"
        elif missing_pct >= 0.1 and status == "PASS":
            status = "WARN"

        messages = [
            f"IMU blocks: {timestamps.size}",
            f"Samples/tick: {samples_per_tick}",
            f"Sample rate: {sample_rate_hz:.2f} Hz",
            f"Missing blocks: {missing_count} ({missing_pct:.3f}%)",
            f"Max Rev/40' assumes {self.logging_speed_fpm:.0f} fpm and {self.joint_length_ft:.0f} ft joints.",
            "Radial offset is IMU-derived and should be treated as an estimated offset proxy.",
        ]
        if np.isfinite(ref_rpm):
            messages.append(f"Reference RPM used for offset estimate: {ref_rpm:.1f}")
        else:
            messages.append("No reference RPM found - IMU-derived offset unavailable")
        if np.isfinite(max_rev_40):
            messages.append(f"Max Rev/40': {max_rev_40:.3f}")

        return ModuleResult(
            name=self.name,
            status=status,
            messages=messages,
            metrics={
                "Rad Vib RMS": (rad_rms, metric_statuses[0], "g"),
                "Ax Vib RMS": (ax_rms, metric_statuses[1], "g"),
                "Peak Shock": (peak_shock, metric_statuses[2], "g"),
                "Rad Decent 95%": (decent_p95, metric_statuses[3], "in"),
                "Max Rev/40'": (max_rev_40, metric_statuses[4], "rev"),
            },
            plot_data={
                "x": x,
                "axis_label": axis_label,
                "rad_vib": self._smooth_edge(rad_rms_series, self.plot_smooth),
                "ax_vib": self._smooth_edge(ax_rms_series, self.plot_smooth),
                "decent": self._smooth_edge(decent_series, self.plot_smooth),
                "warn_vib": self.rad_rms_warn_g,
                "fail_vib": self.rad_rms_fail_g,
                "warn_decent": self.decent_p95_warn_in,
                "fail_decent": self.decent_p95_fail_in,
                "spin_window_start": spin_win_start,
                "spin_window_end": spin_win_end,
            },
        )


    def draw(self, fig, left, bottom, width, height, result: ModuleResult):
        header_h = height * 0.10
        plot_zone_h = height * 0.55
        xband_h = height * 0.05
        box_zone_h = height * 0.30
        pad_left = width * 0.075
        pad_right = width * 0.055
        inner_left = left + pad_left
        inner_width = width - pad_left - pad_right
        title_y = bottom + height - header_h * 0.58
        plot_bottom = bottom + box_zone_h + xband_h + height * 0.025
        plot_h = plot_zone_h - height * 0.055
        boxes_bottom = bottom + height * 0.035
        boxes_h = box_zone_h - height * 0.09

        fig.text(inner_left, title_y, "Accelerometer", fontsize=16, fontweight="bold", ha="left", va="center", color="#1f2937")
        fig.text(inner_left + inner_width, title_y, "Target < 2.0 g RMS", fontsize=10, ha="right", va="center", color="#4b5563")

        if result.status == "ERROR" or not result.plot_data:
            ax = fig.add_axes([inner_left, bottom + box_zone_h + 0.04 * height, inner_width, plot_zone_h + xband_h - 0.08 * height], facecolor="#f7f7f7")
            ax.set_axis_off()
            ax.text(0.5, 0.58, "Accelerometer data unavailable", ha="center", va="center", fontsize=16, fontweight="bold", color="#6b7280")
            msg = "\n".join(result.messages[:3]) if result.messages else "No details"
            ax.text(0.5, 0.32, msg, ha="center", va="center", fontsize=10, color="#6b7280")
            return

        x = np.asarray(result.plot_data.get("x", []), dtype=float)
        rad = np.asarray(result.plot_data.get("rad_vib", []), dtype=float)
        axv = np.asarray(result.plot_data.get("ax_vib", []), dtype=float)
        decent = np.asarray(result.plot_data.get("decent", []), dtype=float)

        valid = np.isfinite(x) & np.isfinite(rad)
        ax = fig.add_axes([inner_left, plot_bottom, inner_width, plot_h], facecolor="white")
        ax.plot(x[valid], rad[valid], linewidth=1.2, color="#4c6ef5", label="Rad Vib RMS")
        valid_ax = np.isfinite(x) & np.isfinite(axv)
        if np.any(valid_ax):
            ax.plot(x[valid_ax], axv[valid_ax], linewidth=0.95, color="#2f9e44", linestyle="--", alpha=0.85, label="Ax Vib RMS")
        vib_top = np.nanpercentile(rad[valid], 99) * 1.25 if np.any(valid) else self.rad_rms_fail_g * 1.25
        vib_top = max(self.rad_rms_fail_g * 1.25, vib_top, self.ax_rms_fail_g * 1.25, 0.25)
        ax.set_ylim(0.0, vib_top)
        ax.set_ylabel("Vibration (g)", fontsize=10.5, color="#2563eb")
        ax.axhline(self.rad_rms_warn_g, linestyle=":", linewidth=0.8, color="#888888", alpha=0.75)
        ax.axhline(self.rad_rms_fail_g, linestyle=":", linewidth=0.9, color="#666666", alpha=0.75)
        ax.spines["top"].set_visible(False)
        ax.tick_params(axis="y", labelsize=8.5, colors="#2563eb", pad=2)
        ax.tick_params(axis="x", labelsize=8.5, colors="#111827", pad=2)
        ax.spines["left"].set_color("#2563eb")
        ax.legend(loc="upper left", fontsize=8.5, frameon=False, ncol=2, columnspacing=1.2, handlelength=2.0)

        valid_dec = np.isfinite(x) & np.isfinite(decent)
        if np.any(valid_dec):
            ax2 = ax.twinx()
            ax2.plot(x[valid_dec], decent[valid_dec], color="#d94841", linewidth=1.2, linestyle="--", alpha=0.95)
            hi = float(np.nanpercentile(decent[valid_dec], 99) * 1.15)
            hi = max(self.decent_p95_fail_in * 1.2, hi, 0.08)
            ax2.set_ylim(0.0, hi)
            ax2.axhline(self.decent_p95_warn_in, linestyle=":", linewidth=0.8, color="#d94841", alpha=0.75)
            ax2.axhline(self.decent_p95_fail_in, linestyle=":", linewidth=0.9, color="#d94841", alpha=0.75)
            ax2.set_ylabel("Rad Decent Est (in)", fontsize=10.5, color="#d94841", labelpad=10)
            ax2.tick_params(axis="y", labelsize=8.5, colors="#d94841", pad=2)
            ax2.spines["top"].set_visible(False)
            ax2.spines["right"].set_color("#d94841")


        labels = list(result.metrics.keys())
        statuses = []
        values = []
        for lab in labels:
            v, s, units = result.metrics[lab]
            statuses.append(s)
            values.append(self._format_metric(v, units, 3))
        draw_metric_row(
            fig,
            left=inner_left,
            bottom=boxes_bottom,
            width=inner_width,
            height=boxes_h,
            labels=labels,
            values=values,
            statuses=statuses,
            gap_fraction=0.014,
            edgecolor="#9aa0a6",
            linewidth=1.0,
            value_fontsize=10.2,
            label_fontsize=8.3,
            value_fontweight="bold",
            label_fontweight="bold",
            text_color="#1f2937",
            label_color="#374151",
            show_markers=True,
            marker_radius=0.016,
            marker_color="#000000",
        )
