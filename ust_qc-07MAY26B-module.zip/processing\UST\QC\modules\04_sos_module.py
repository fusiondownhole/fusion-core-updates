import numpy as np

from base import BaseModule, ModuleResult
from h5_utils import first_available, to_float_array
from pressure_context import estimate_pressure_density_context
from report_ui import draw_metric_row


class SoSModule(BaseModule):
    name = "SoS"

    def __init__(
        self,
        sos_paths=None,
        rev_paths=None,
        timestamp_paths=None,
        signal_paths=None,
        temp_paths=None,
        pressure_paths=None,
        aggregate_points=4,
        outlier_window=31,
        outlier_limit_mps=30.0,
        median_window=41,
        smooth_window=241,
        gas_head_window_pct=0.08,
    ):
        self.sos_paths = sos_paths or [
            "secondary_sensors/TOF/speed_of_sound",
            "main_sensor/speed_of_sound",
            "speed_of_sound",
        ]
        self.rev_paths = rev_paths or [
            "secondary_sensors/TOF/rev_number",
            "secondary_sensors/PT/rev_number",
            "tool/rev_number",
            "main_sensor/rev_number",
            "rev_number",
        ]
        self.timestamp_paths = timestamp_paths or [
            "secondary_sensors/TOF/timestamp",
            "secondary_sensors/PT/timestamp",
            "tool/timestamp",
            "main_sensor/timestamp",
            "timestamp",
        ]
        self.signal_paths = signal_paths or [
            "secondary_sensors/TOF/echo_peak_level",
            "main_sensor/echo_peak_level",
            "echo_peak_level",
        ]
        self.temp_paths = temp_paths or [
            "secondary_sensors/PT/temperature",
            "tool/sensor_board_temperature",
            "tool/main_board_temperature",
        ]
        self.pressure_paths = pressure_paths or [
            "secondary_sensors/PT/pressure",
        ]
        self.aggregate_points = max(1, int(aggregate_points))
        self.outlier_window = int(outlier_window)
        self.outlier_limit_mps = float(outlier_limit_mps)
        self.median_window = int(median_window)
        self.smooth_window = int(smooth_window)
        self.gas_head_window_pct = float(gas_head_window_pct)

        self.signal_thresholds = {
            "good": 2000.0,
            "marginal": 1000.0,
            "bad": 500.0,
        }

    def _smooth_edge(self, x, w):
        x = np.asarray(x, dtype=float)
        if x.size == 0:
            return x.copy()
        w = max(1, min(int(w), x.size))
        if w <= 1:
            return x.copy()
        pad_left = w // 2
        pad_right = w - 1 - pad_left
        xpad = np.pad(x, (pad_left, pad_right), mode="edge")
        return np.convolve(xpad, np.ones(w) / w, mode="valid")

    def _rolling_median(self, x, w):
        x = np.asarray(x, dtype=float)
        if x.size == 0:
            return x.copy()
        w = max(1, min(int(w), x.size))
        if w <= 1:
            return x.copy()
        try:
            from numpy.lib.stride_tricks import sliding_window_view
            pad_left = w // 2
            pad_right = w - 1 - pad_left
            xpad = np.pad(x, (pad_left, pad_right), mode="edge")
            return np.median(sliding_window_view(xpad, w), axis=-1)
        except Exception:
            return self._smooth_edge(x, w)

    def _aggregate_series(self, x, y, t, sig, temp, pressure, npts):
        arrays = [np.asarray(a, dtype=float) for a in (x, y, t, sig, temp, pressure)]
        npts = max(1, int(npts))
        if npts <= 1 or arrays[0].size < npts:
            return [a.copy() for a in arrays]
        n = (arrays[0].size // npts) * npts
        if n < npts:
            return [a.copy() for a in arrays]
        outs = []
        reducers = [np.nanmean, np.nanmean, np.nanmean, np.nanmedian, np.nanmean, np.nanmean]
        for arr, reducer in zip(arrays, reducers):
            core = reducer(arr[:n].reshape(-1, npts), axis=1)
            if n < arr.size:
                core = np.concatenate([core, [reducer(arr[n:])]])
            outs.append(core)
        return outs

    def _water_sos_from_temp_c(self, temp_c):
        temp_c = np.asarray(temp_c, dtype=float)
        return 1402.385 + 5.038813 * temp_c - 0.05792707 * (temp_c ** 2) + 0.0003302818 * (temp_c ** 3)


    def _temp_c_from_water_sos(self, sos_mps):
        sos_mps = np.asarray(sos_mps, dtype=float)
        out = np.full_like(sos_mps, np.nan, dtype=float)
        valid = np.isfinite(sos_mps)
        if not np.any(valid):
            return out
        grid_c = np.linspace(-5.0, 120.0, 2501)
        grid_sos = self._water_sos_from_temp_c(grid_c)
        order = np.argsort(grid_sos)
        grid_sos = grid_sos[order]
        grid_c = grid_c[order]
        lo = float(np.nanmin(grid_sos))
        hi = float(np.nanmax(grid_sos))
        vals = np.clip(sos_mps[valid], lo, hi)
        out[valid] = np.interp(vals, grid_sos, grid_c)
        return out

    def _classify_fluid(self, delta_mps, gas_at_head=False):
        if gas_at_head:
            return "Water / Brine with gas at top"
        if not np.isfinite(delta_mps):
            return "Unknown"
        if delta_mps < -180.0:
            return "Oil / OBM"
        if delta_mps < 40.0:
            return "Water"
        if delta_mps < 180.0:
            return "Brine"
        return "Brine > 25%"

    def _confidence_label(self, confidence_pct):
        if confidence_pct >= 66.0:
            return "High"
        if confidence_pct >= 33.0:
            return "Medium"
        return "Low"

    def _fit_quality_score(self, residual_p95, good_default=100.0, warn=25.0, fail=90.0):
        if not np.isfinite(residual_p95):
            return 40.0
        if residual_p95 <= warn:
            return good_default
        if residual_p95 >= fail:
            return 0.0
        return float(np.clip(100.0 * (fail - residual_p95) / (fail - warn), 0.0, 100.0))

    def _longest_run_fraction(self, mask):
        mask = np.asarray(mask, dtype=bool).reshape(-1)
        if mask.size == 0:
            return 0.0
        best = 0
        run = 0
        for v in mask:
            if v:
                run += 1
                best = max(best, run)
            else:
                run = 0
        return float(best) / float(mask.size)

    def _rolling_span(self, x, w):
        x = np.asarray(x, dtype=float)
        if x.size == 0:
            return x.copy()
        w = max(1, min(int(w), x.size))
        if w <= 1:
            return np.zeros_like(x, dtype=float)
        try:
            from numpy.lib.stride_tricks import sliding_window_view
            pad_left = w // 2
            pad_right = w - 1 - pad_left
            xpad = np.pad(x, (pad_left, pad_right), mode="edge")
            windows = sliding_window_view(xpad, w)
            return np.nanmax(windows, axis=-1) - np.nanmin(windows, axis=-1)
        except Exception:
            return np.zeros_like(x, dtype=float)

    def _interp_finite(self, x):
        x = np.asarray(x, dtype=float)
        if x.size == 0:
            return x.copy()
        valid = np.isfinite(x)
        if np.count_nonzero(valid) < 2:
            return x.copy()
        idx = np.arange(x.size, dtype=float)
        return np.interp(idx, idx[valid], x[valid])

    def _dynamic_pt_context(self, temp_c, pressure):
        temp_c = np.asarray(temp_c, dtype=float)
        pressure = np.asarray(pressure, dtype=float)
        n = max(temp_c.size, pressure.size)
        if n == 0:
            return np.zeros(0, dtype=bool), {
                "pt_dynamic_frac": np.nan,
                "temp_dynamic_frac": np.nan,
                "pressure_dynamic_frac": np.nan,
            }

        small_w = max(7, min(61, int(round(n * 0.015)) | 1))
        large_w = max(31, min(301, int(round(n * 0.08)) | 1))

        temp_dynamic = np.zeros(n, dtype=bool)
        temp_f = temp_c * 9.0 / 5.0 + 32.0
        if np.count_nonzero(np.isfinite(temp_f)) >= 8:
            temp_f = self._interp_finite(temp_f)
            temp_fast = self._smooth_edge(temp_f, small_w)
            temp_slow = self._smooth_edge(temp_f, large_w)
            temp_dev = np.abs(temp_fast - temp_slow)
            temp_span = self._rolling_span(temp_fast, small_w)
            temp_dev_thr = max(1.5, float(np.nanpercentile(temp_dev, 85)) if np.any(np.isfinite(temp_dev)) else 1.5)
            temp_span_thr = max(3.0, float(np.nanpercentile(temp_span, 85)) if np.any(np.isfinite(temp_span)) else 3.0)
            temp_dynamic = (temp_dev >= temp_dev_thr) | (temp_span >= temp_span_thr)

        pressure_dynamic = np.zeros(n, dtype=bool)
        if np.count_nonzero(np.isfinite(pressure)) >= 8:
            pressure = self._interp_finite(pressure)
            pressure_fast = self._smooth_edge(pressure, small_w)
            pressure_slow = self._smooth_edge(pressure, large_w)
            pressure_dev = np.abs(pressure_fast - pressure_slow)
            pressure_span = self._rolling_span(pressure_fast, small_w)
            pressure_dev_thr = max(12.0, float(np.nanpercentile(pressure_dev, 85)) if np.any(np.isfinite(pressure_dev)) else 12.0)
            pressure_span_thr = max(25.0, float(np.nanpercentile(pressure_span, 85)) if np.any(np.isfinite(pressure_span)) else 25.0)
            pressure_dynamic = (pressure_dev >= pressure_dev_thr) | (pressure_span >= pressure_span_thr)

        dynamic = temp_dynamic | pressure_dynamic
        if dynamic.size:
            dynamic = self._smooth_edge(dynamic.astype(float), small_w) >= 0.25

        return dynamic, {
            "pt_dynamic_frac": 100.0 * float(np.mean(dynamic)) if dynamic.size else np.nan,
            "temp_dynamic_frac": 100.0 * float(np.mean(temp_dynamic)) if temp_dynamic.size else np.nan,
            "pressure_dynamic_frac": 100.0 * float(np.mean(pressure_dynamic)) if pressure_dynamic.size else np.nan,
        }

    def _trend_model_consistency(self, x, sos_smooth, expected_model, usable_mask, context_mask=None):
        x = np.asarray(x, dtype=float)
        sos_smooth = np.asarray(sos_smooth, dtype=float)
        expected_model = np.asarray(expected_model, dtype=float)
        usable_mask = np.asarray(usable_mask, dtype=bool)
        if context_mask is None:
            context_mask = np.zeros_like(usable_mask, dtype=bool)
        else:
            context_mask = np.asarray(context_mask, dtype=bool)
            if context_mask.size != usable_mask.size:
                context_mask = np.zeros_like(usable_mask, dtype=bool)

        valid = np.isfinite(x) & np.isfinite(sos_smooth) & np.isfinite(expected_model) & usable_mask
        if np.count_nonzero(valid) < 8:
            return {
                "trend_resid_p95": np.nan,
                "model_resid_p95": np.nan,
                "model_resid_p95_raw": np.nan,
                "pt_dynamic_overlap_frac": np.nan,
                "continuity_frac": np.nan,
            }

        local_trend = self._smooth_edge(sos_smooth, max(9, min(61, len(sos_smooth))))
        trend_resid = np.abs((sos_smooth - local_trend)[valid])
        model_resid_all = np.abs(sos_smooth - expected_model)
        stable_valid = valid & ~context_mask
        if np.count_nonzero(stable_valid) >= max(8, int(round(0.25 * np.count_nonzero(valid)))):
            model_resid = model_resid_all[stable_valid]
        else:
            model_resid = model_resid_all[valid]

        high_resid = valid & (model_resid_all >= max(18.0, float(np.nanpercentile(model_resid_all[valid], 75))))
        pt_dynamic_overlap_frac = (
            float(np.mean(context_mask[high_resid])) if np.count_nonzero(high_resid) else np.nan
        )

        usable_run_frac = self._longest_run_fraction(usable_mask)
        continuity_frac = 1.0 - usable_run_frac
        continuity_frac = float(np.clip(np.mean(usable_mask), 0.0, 1.0))

        return {
            "trend_resid_p95": float(np.nanpercentile(trend_resid, 95)) if trend_resid.size else np.nan,
            "model_resid_p95": float(np.nanpercentile(model_resid, 95)) if model_resid.size else np.nan,
            "model_resid_p95_raw": float(np.nanpercentile(model_resid_all[valid], 95)) if np.count_nonzero(valid) else np.nan,
            "pt_dynamic_overlap_frac": pt_dynamic_overlap_frac,
            "continuity_frac": continuity_frac,
        }

    def _detect_linear_break_region(self, x, sos_smooth):
        x = np.asarray(x, dtype=float)
        y = np.asarray(sos_smooth, dtype=float)
        valid = np.isfinite(x) & np.isfinite(y)
        x = x[valid]
        y = y[valid]
        if x.size < 40:
            return {"break_start_rev": np.nan, "break_end_rev": np.nan, "break_mask": np.zeros_like(sos_smooth, dtype=bool), "break_strength": np.nan}

        n_fit = max(12, int(round(0.65 * x.size)))
        fit_x = x[:n_fit]
        fit_y = y[:n_fit]
        try:
            slope, intercept = np.polyfit(fit_x, fit_y, 1)
        except Exception:
            return {"break_start_rev": np.nan, "break_end_rev": np.nan, "break_mask": np.zeros_like(sos_smooth, dtype=bool), "break_strength": np.nan}

        baseline = slope * x + intercept
        resid = y - baseline
        grad = np.gradient(y, x)
        base_grad = float(np.nanmedian(grad[:n_fit])) if n_fit >= 5 else float(np.nanmedian(grad))
        grad_dev = np.abs(grad - base_grad)
        resid_abs = np.abs(resid)

        resid_thr = max(12.0, float(np.nanpercentile(resid_abs[:n_fit], 95)) * 2.5 if n_fit >= 8 else 12.0)
        grad_thr = max(0.015, float(np.nanpercentile(grad_dev[:n_fit], 95)) * 2.5 if n_fit >= 8 else 0.015)
        candidate = (resid_abs >= resid_thr) | (grad_dev >= grad_thr)
        candidate[: max(8, int(0.15 * x.size))] = False

        # Require a persistent break, not a single-point spike
        min_run = max(6, int(round(0.04 * x.size)))
        best = (None, None)
        run_start = None
        run_len = 0
        for i, flag in enumerate(candidate):
            if flag:
                if run_start is None:
                    run_start = i
                run_len += 1
            else:
                if run_start is not None and run_len >= min_run:
                    best = (run_start, i - 1)
                    break
                run_start = None
                run_len = 0
        if best == (None, None) and run_start is not None and run_len >= min_run:
            best = (run_start, len(candidate) - 1)

        full_mask = np.zeros_like(sos_smooth, dtype=bool)
        if best == (None, None):
            return {"break_start_rev": np.nan, "break_end_rev": np.nan, "break_mask": full_mask, "break_strength": np.nan}

        s, e = best
        valid_idx = np.where(valid)[0]
        full_mask[valid_idx[s:e+1]] = True
        strength = float(np.nanpercentile(resid_abs[s:e+1], 90)) if e >= s else np.nan
        return {
            "break_start_rev": float(x[s]),
            "break_end_rev": float(x[e]),
            "break_mask": full_mask,
            "break_strength": strength,
        }

    def _estimate_salinity(self, delta_mps, gas_at_head=False, pressure_density=np.nan):
        if gas_at_head and (not np.isfinite(delta_mps) or delta_mps < 40.0):
            return "Near fresh / low salinity"
        if not np.isfinite(delta_mps):
            return "Unknown"
        if delta_mps < 40.0:
            sal = "Fresh / <5%"
        elif delta_mps < 110.0:
            sal = "Light brine / 5-10%"
        elif delta_mps < 180.0:
            sal = "Brine / 10-25%"
        else:
            sal = "Brine > 25%"

        if np.isfinite(pressure_density):
            if sal == "Fresh / <5%" and pressure_density > 1.08:
                sal = "Light brine / 5-10%"
            elif sal == "Light brine / 5-10%" and pressure_density < 1.01:
                sal = "Fresh / <5%"
            elif sal == "Brine / 10-25%" and pressure_density < 1.06:
                sal = "Light brine / 5-10%"
            elif sal == "Light brine / 5-10%" and pressure_density > 1.15:
                sal = "Brine / 10-25%"
        return sal

    def _confidence_score(
        self,
        good_pct,
        p95_noise,
        delta_spread,
        trend_resid_p95=np.nan,
        model_resid_p95=np.nan,
        continuity_frac=np.nan,
        pressure_density=np.nan,
        pressure_conf=np.nan,
        fluid_guess="Unknown",
    ):
        good_frac = float(np.clip(good_pct / 100.0, 0.0, 1.0)) if np.isfinite(good_pct) else 0.0
        continuity = float(np.clip(continuity_frac, 0.0, 1.0)) if np.isfinite(continuity_frac) else 0.0

        if np.isfinite(p95_noise):
            if p95_noise < 10.0:
                noise_score = 1.0
            elif p95_noise < 20.0:
                noise_score = 0.8
            elif p95_noise < 35.0:
                noise_score = 0.6
            elif p95_noise < 50.0:
                noise_score = 0.35
            else:
                noise_score = 0.10
        else:
            noise_score = 0.25

        if np.isfinite(delta_spread):
            if delta_spread < 15.0:
                spread_score = 1.0
            elif delta_spread < 35.0:
                spread_score = 0.75
            elif delta_spread < 60.0:
                spread_score = 0.45
            else:
                spread_score = 0.15
        else:
            spread_score = 0.25

        if np.isfinite(trend_resid_p95):
            if trend_resid_p95 < 5.0:
                trend_score = 1.0
            elif trend_resid_p95 < 15.0:
                trend_score = 0.7
            elif trend_resid_p95 < 30.0:
                trend_score = 0.4
            else:
                trend_score = 0.1
        else:
            trend_score = 0.35

        model_fit_score = self._fit_quality_score(model_resid_p95, good_default=100.0, warn=18.0, fail=80.0) / 100.0

        pressure_prior = 0.25
        if np.isfinite(pressure_density):
            if fluid_guess in ("Water", "Brine", "Brine > 25%", "Water / Brine with gas at top"):
                pressure_prior = 0.55
                if np.isfinite(pressure_conf):
                    pressure_prior = min(1.0, 0.25 + 0.75 * float(np.clip(pressure_conf / 100.0, 0.0, 1.0)))
            elif fluid_guess == "Oil / OBM":
                pressure_prior = 0.35
        elif np.isfinite(pressure_conf):
            pressure_prior = float(np.clip(pressure_conf / 100.0, 0.0, 1.0)) * 0.5

        score = (
            0.30 * good_frac
            + 0.15 * noise_score
            + 0.10 * spread_score
            + 0.10 * continuity
            + 0.20 * model_fit_score
            + 0.05 * pressure_prior
            + 0.10 * trend_score
        )

        score_pct = 100.0 * float(np.clip(score, 0.0, 1.0))

        if fluid_guess in ("Water", "Brine") and good_frac >= 0.25 and model_fit_score >= 0.70 and continuity >= 0.40:
            score_pct = max(score_pct, 72.0)

        if good_frac < 0.10:
            score_pct = min(score_pct, 45.0)

        return score_pct

    def compute(self, h5):
        sos_path, sos_data = first_available(h5, self.sos_paths)
        rev_path, rev_data = first_available(h5, self.rev_paths)
        time_path, time_data = first_available(h5, self.timestamp_paths)
        signal_path, signal_data = first_available(h5, self.signal_paths)
        temp_path, temp_data = first_available(h5, self.temp_paths)
        pressure_path, pressure_data = first_available(h5, self.pressure_paths)

        if sos_data is None:
            return ModuleResult(name=self.name, status="ERROR", messages=["No speed of sound dataset found"], metrics={}, plot_data={})
        if rev_data is None:
            return ModuleResult(name=self.name, status="ERROR", messages=["No revolution dataset found"], metrics={}, plot_data={})
        if time_data is None:
            return ModuleResult(name=self.name, status="ERROR", messages=["No timestamp dataset found"], metrics={}, plot_data={})
        if temp_data is None:
            return ModuleResult(name=self.name, status="ERROR", messages=["No temperature dataset found for SoS correction"], metrics={}, plot_data={})

        sos = to_float_array(sos_data).reshape(-1)
        rev = to_float_array(rev_data).reshape(-1)
        ts = to_float_array(time_data).reshape(-1)
        sig = to_float_array(signal_data).reshape(-1) if signal_data is not None else np.full_like(sos, np.nan, dtype=float)
        temp_c = to_float_array(temp_data).reshape(-1)
        pressure = to_float_array(pressure_data).reshape(-1) if pressure_data is not None else np.full_like(sos, np.nan, dtype=float)

        n = min(len(sos), len(rev), len(ts), len(sig), len(temp_c), len(pressure))
        sos, rev, ts, sig, temp_c, pressure = sos[:n], rev[:n], ts[:n], sig[:n], temp_c[:n], pressure[:n]

        valid = np.isfinite(sos) & np.isfinite(rev) & np.isfinite(ts) & np.isfinite(temp_c)
        if not np.any(valid):
            return ModuleResult(name=self.name, status="ERROR", messages=["No finite SoS samples after alignment"], metrics={}, plot_data={})

        sos, rev, ts, sig, temp_c, pressure = sos[valid], rev[valid], ts[valid], sig[valid], temp_c[valid], pressure[valid]
        order = np.argsort(rev)
        sos, rev, ts, sig, temp_c, pressure = sos[order], rev[order], ts[order], sig[order], temp_c[order], pressure[order]

        uniq_rev, uniq_idx = np.unique(rev, return_index=True)
        sos, ts, sig, temp_c, pressure = sos[uniq_idx], ts[uniq_idx], sig[uniq_idx], temp_c[uniq_idx], pressure[uniq_idx]
        rev = uniq_rev

        if rev.size < 10:
            return ModuleResult(name=self.name, status="ERROR", messages=["SoS module needs at least 10 samples"], metrics={}, plot_data={})

        rev, sos, ts, sig, temp_c, pressure = self._aggregate_series(rev, sos, ts, sig, temp_c, pressure, self.aggregate_points)

        med = self._rolling_median(sos, self.outlier_window)
        clean = sos.copy()
        bad_jump = np.abs(sos - med) > self.outlier_limit_mps
        clean[bad_jump] = med[bad_jump]
        clean = self._rolling_median(clean, self.median_window)
        sos_s = self._smooth_edge(clean, self.smooth_window)

        expected_water = self._water_sos_from_temp_c(temp_c)
        delta = sos_s - expected_water
        p95_noise = float(np.nanpercentile(np.abs(sos - sos_s), 95)) if np.any(np.isfinite(sos_s)) else float("nan")
        delta_median = float(np.nanmedian(delta)) if np.any(np.isfinite(delta)) else float("nan")
        delta_spread = float(np.nanpercentile(np.abs(delta - delta_median), 95)) if np.any(np.isfinite(delta)) else float("nan")
        avg_sos = float(np.nanmean(sos_s)) if np.any(np.isfinite(sos_s)) else float("nan")

        classify_mask = np.isfinite(rev) & (rev >= 1000.0) & (rev <= 2000.0) & np.isfinite(delta)
        if np.count_nonzero(classify_mask) < 20:
            classify_mask = np.isfinite(rev) & (rev <= 2000.0) & np.isfinite(delta)
        if np.count_nonzero(classify_mask) < 20:
            classify_mask = np.isfinite(delta)

        classify_delta = delta[classify_mask]

        signal_level = np.asarray(sig, dtype=float)
        good_mask = signal_level >= self.signal_thresholds["good"]
        marginal_mask = (signal_level >= self.signal_thresholds["marginal"]) & (signal_level < self.signal_thresholds["good"])
        bad_mask = signal_level < self.signal_thresholds["marginal"]

        good_pct = 100.0 * float(np.mean(good_mask)) if signal_level.size else float("nan")
        marginal_pct = 100.0 * float(np.mean(marginal_mask)) if signal_level.size else float("nan")
        bad_pct = 100.0 * float(np.mean(bad_mask)) if signal_level.size else float("nan")

        head_n = max(5, int(round(self.gas_head_window_pct * len(sos_s))))
        gas_at_head = bool(np.nanpercentile(sos_s[:head_n], 25) < 900.0) if head_n > 0 else False
        classify_delta_median = float(np.nanmedian(classify_delta)) if np.any(np.isfinite(classify_delta)) else float("nan")
        fluid_guess = self._classify_fluid(classify_delta_median, gas_at_head=gas_at_head)

        pressure_ctx = estimate_pressure_density_context(h5)
        pressure_density = float(pressure_ctx.get("est_density_gcc", float("nan")))
        pressure_conf = float(pressure_ctx.get("confidence_pct", float("nan")))

        estimated_salinity = self._estimate_salinity(
            classify_delta_median,
            gas_at_head=gas_at_head,
            pressure_density=pressure_density,
        )

        expected_model = expected_water + (classify_delta_median if np.isfinite(classify_delta_median) else 0.0)
        usable_mask = good_mask | marginal_mask
        pt_dynamic_mask, pt_dynamic_meta = self._dynamic_pt_context(temp_c, pressure)
        fit_meta = self._trend_model_consistency(rev, sos_s, expected_model, usable_mask, context_mask=pt_dynamic_mask)

        trend_resid_p95 = fit_meta.get("trend_resid_p95", np.nan)
        model_resid_p95 = fit_meta.get("model_resid_p95", np.nan)
        model_resid_p95_raw = fit_meta.get("model_resid_p95_raw", np.nan)
        pt_dynamic_overlap_frac = fit_meta.get("pt_dynamic_overlap_frac", np.nan)
        continuity_frac = fit_meta.get("continuity_frac", np.nan)
        break_meta = self._detect_linear_break_region(rev, sos_s)

        confidence_pct = self._confidence_score(
            good_pct=good_pct,
            p95_noise=p95_noise,
            delta_spread=delta_spread,
            trend_resid_p95=trend_resid_p95,
            model_resid_p95=model_resid_p95,
            continuity_frac=continuity_frac,
            pressure_density=pressure_density,
            pressure_conf=pressure_conf,
            fluid_guess=fluid_guess,
        )
        confidence = self._confidence_label(confidence_pct)

        status = "PASS"
        if confidence_pct < 66.0 or good_pct < 50.0 or p95_noise > 20.0:
            status = "WARN"
        if confidence_pct < 33.0 or good_pct < 30.0 or p95_noise > 40.0:
            status = "FAIL"
        if status == "FAIL" and np.isfinite(pt_dynamic_overlap_frac) and pt_dynamic_overlap_frac >= 0.50:
            status = "WARN"

        second_bounce_frac = float(np.mean(np.asarray(sig, dtype=float) < 0.0)) if len(sig) else float("nan")

        pressure_note = "Pressure prior unavailable"
        if np.isfinite(pressure_density):
            if np.isfinite(pressure_conf):
                pressure_note = f"Pressure prior: {pressure_density:.2f} g/cc ({pressure_conf:.0f}% confidence)"
            else:
                pressure_note = f"Pressure prior: {pressure_density:.2f} g/cc"
        elif pressure_data is not None and np.any(np.isfinite(pressure)):
            p_span = float(np.nanmax(pressure) - np.nanmin(pressure))
            pressure_note = f"Pressure span observed: {p_span:.1f} psi"

        messages = [
            f"SoS source: {sos_path}",
            f"Temperature correction source: {temp_path}",
            f"Signal source: {signal_path}",
            f"Estimated dominant fluid: {fluid_guess}",
            f"Median delta vs temperature-corrected water: {delta_median:.1f} m/s" if np.isfinite(delta_median) else "Median delta unavailable",
            pressure_note,
            (f"P/T dynamic coverage: {pt_dynamic_meta['pt_dynamic_frac']:.1f}% of SoS samples" if np.isfinite(pt_dynamic_meta.get("pt_dynamic_frac", np.nan)) else "P/T dynamic coverage unavailable"),
            (f"SoS model deviation overlap with P/T dynamic intervals: {100.0 * pt_dynamic_overlap_frac:.1f}%" if np.isfinite(pt_dynamic_overlap_frac) else "SoS model deviation overlap unavailable"),
            f"Negative SoS signal fraction: {100.0 * second_bounce_frac:.1f}%" if np.isfinite(second_bounce_frac) else "Negative SoS signal fraction unavailable",
            f"Good-sample trend fit P95: {trend_resid_p95:.1f} m/s" if np.isfinite(trend_resid_p95) else "Good-sample trend fit unavailable",
            (f"Possible linear-break region: rev {break_meta['break_start_rev']:.0f} to {break_meta['break_end_rev']:.0f}" if np.isfinite(break_meta.get('break_start_rev', np.nan)) and np.isfinite(break_meta.get('break_end_rev', np.nan)) else "No persistent linear-break region detected"),
        ]

        warning_intervals = []
        if status in {"WARN", "FAIL"}:
            break_start = break_meta.get("break_start_rev", np.nan)
            break_end = break_meta.get("break_end_rev", np.nan)
            if np.isfinite(break_start) and np.isfinite(break_end) and break_end > break_start:
                warning_intervals.append(
                    {
                        "start_rev": float(break_start),
                        "end_rev": float(break_end),
                    }
                )

        return ModuleResult(
            name=self.name,
            status=status,
            messages=messages,
            metrics={
                "Avg SoS": (
                    avg_sos,
                    "INFO",
                    "m/s",
                ),
                "P95 Noise": (
                    p95_noise,
                    "PASS" if p95_noise <= 20.0 else "WARN" if p95_noise <= 40.0 else "FAIL",
                    "m/s",
                ),
                "Good Signal": (
                    good_pct,
                    "PASS" if good_pct >= 80.0 else "WARN" if good_pct >= 50.0 else "FAIL",
                    "%",
                ),
                "Fluid Guess": (
                    0,
                    "PASS" if confidence_pct >= 66.0 else "WARN" if confidence_pct >= 33.0 else "FAIL",
                    fluid_guess,
                ),
                "Est. Salinity": (
                    0,
                    "INFO",
                    estimated_salinity,
                ),
            },
            plot_data={
                "x": rev,
                "sos_raw": sos,
                "sos_smooth": sos_s,
                "expected_water": expected_water,
                "expected_model": expected_model,
                "delta": delta,
                "temp_c": temp_c,
                "signal_level": signal_level,
                "signal_plot": self._smooth_edge(signal_level, max(5, min(61, len(signal_level)))),
                "est_fluid_temp_f": self._smooth_edge(self._temp_c_from_water_sos(sos_s) * 9.0 / 5.0 + 32.0, max(5, min(61, len(sos_s)))),
                "signal_good_mask": good_mask,
                "signal_marginal_mask": marginal_mask,
                "signal_bad_mask": bad_mask,
                "signal_thresholds": self.signal_thresholds,
                "fluid_guess": fluid_guess,
                "estimated_salinity": estimated_salinity,
                "confidence": confidence,
                "confidence_pct": confidence_pct,
                "good_pct": good_pct,
                "marginal_pct": marginal_pct,
                "bad_pct": bad_pct,
                "delta_median": delta_median,
                "delta_spread": delta_spread,
                "gas_at_head": gas_at_head,
                "pressure_density": pressure_density,
                "pressure_conf": pressure_conf,
                "second_bounce_frac": second_bounce_frac,
                "trend_resid_p95": trend_resid_p95,
                "model_resid_p95": model_resid_p95,
                "model_resid_p95_raw": model_resid_p95_raw,
                "pt_dynamic_mask": pt_dynamic_mask,
                "pt_dynamic_frac": pt_dynamic_meta.get("pt_dynamic_frac", float("nan")),
                "pt_dynamic_overlap_frac": pt_dynamic_overlap_frac,
                "continuity_frac": continuity_frac,
                "break_start_rev": break_meta.get("break_start_rev", float("nan")),
                "break_end_rev": break_meta.get("break_end_rev", float("nan")),
                "break_mask": break_meta.get("break_mask", np.zeros_like(rev, dtype=bool)),
                "break_strength": break_meta.get("break_strength", float("nan")),
                "warning_intervals": warning_intervals,
                "classify_rev_min": float(np.nanmin(rev[classify_mask])) if np.any(classify_mask) else float("nan"),
                "classify_rev_max": float(np.nanmax(rev[classify_mask])) if np.any(classify_mask) else float("nan"),
            },
        )

    def _draw_signal_strip(self, ax, x, signal_level, masks, thresholds):
        ax.set_ylim(0, 1)
        ax.set_yticks([])
        if len(x) == 0:
            return

        colors = [
            (masks[2], "#efb0b0"),
            (masks[1], "#f6d38b"),
            (masks[0], "#b8d3b8"),
        ]
        for mask, color in colors:
            start = None
            for i, flag in enumerate(mask):
                if flag and start is None:
                    start = i
                if start is not None and ((not flag) or i == len(mask) - 1):
                    end = i if not flag else i + 1
                    ax.axvspan(x[start], x[end - 1], color=color, alpha=0.95)
                    start = None

        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.spines["left"].set_visible(False)
        ax.spines["bottom"].set_color("#9ca3af")
        ax.tick_params(axis="x", labelbottom=True, labelsize=8.5, pad=2)
        ax.text(
            0.0,
            1.10,
            f"Signal Level  |  green >= {int(thresholds['good'])}  amber >= {int(thresholds['marginal'])}  red < {int(thresholds['marginal'])}",
            transform=ax.transAxes,
            ha="left",
            va="bottom",
            fontsize=8.2,
            color="#6b7280",
        )

    def draw(self, fig, left, bottom, width, height, result: ModuleResult):
        pad_left = width * 0.075
        pad_right = width * 0.055
        inner_left = left + pad_left
        inner_width = width - pad_left - pad_right
        title_y = bottom + height - height * 0.085
        box_bottom = bottom + height * 0.015
        box_h = height * 0.16
        signal_bottom = bottom + height * 0.245
        signal_h = height * 0.085
        plot_bottom = bottom + height * 0.42
        plot_h = height * 0.435

        fig.text(
            inner_left,
            title_y,
            "Speed of Sound",
            fontsize=16,
            fontweight="bold",
            ha="left",
            va="center",
            color="#1f2937",
        )

        if result.status == "ERROR" or not result.plot_data:
            ax = fig.add_axes([inner_left, bottom + height * 0.18, inner_width, height * 0.52], facecolor="#f7f7f7")
            ax.set_axis_off()
            ax.text(
                0.5,
                0.58,
                "Speed of sound data unavailable",
                ha="center",
                va="center",
                fontsize=16,
                fontweight="bold",
                color="#6b7280",
            )
            msg = "\n".join(result.messages[:3]) if result.messages else "No details"
            ax.text(0.5, 0.30, msg, ha="center", va="center", fontsize=10, color="#6b7280")
            return

        x = np.asarray(result.plot_data.get("x", []), dtype=float)
        sos_raw = np.asarray(result.plot_data.get("sos_raw", []), dtype=float)
        sos_smooth = np.asarray(result.plot_data.get("sos_smooth", []), dtype=float)
        expected_water = np.asarray(result.plot_data.get("expected_water", []), dtype=float)
        expected_model = np.asarray(result.plot_data.get("expected_model", expected_water), dtype=float)
        signal_level = np.asarray(result.plot_data.get("signal_level", []), dtype=float)
        signal_plot = np.asarray(result.plot_data.get("signal_plot", []), dtype=float)
        good_mask = np.asarray(result.plot_data.get("signal_good_mask", []), dtype=bool)
        marginal_mask = np.asarray(result.plot_data.get("signal_marginal_mask", []), dtype=bool)
        bad_mask = np.asarray(result.plot_data.get("signal_bad_mask", []), dtype=bool)
        thresholds = dict(result.plot_data.get("signal_thresholds", {}))
        break_start_rev = float(result.plot_data.get("break_start_rev", np.nan))
        break_end_rev = float(result.plot_data.get("break_end_rev", np.nan))

        ax = fig.add_axes([inner_left, plot_bottom, inner_width, plot_h], facecolor="white")
        valid_raw = np.isfinite(x) & np.isfinite(sos_raw)
        valid_s = np.isfinite(x) & np.isfinite(sos_smooth)
        valid_w = np.isfinite(x) & np.isfinite(expected_model)

        if np.isfinite(break_start_rev) and np.isfinite(break_end_rev) and break_end_rev > break_start_rev:
            ax.axvspan(break_start_rev, break_end_rev, color="#fde68a", alpha=0.22, zorder=0)
        if np.any(valid_raw):
            ax.plot(x[valid_raw], sos_raw[valid_raw], color="#c7ccd4", linewidth=0.6, alpha=0.45, zorder=1)
        if np.any(valid_w):
            ax.plot(x[valid_w], expected_model[valid_w], color="#6b7280", linestyle="--", linewidth=1.1, zorder=2)
        if np.any(valid_s):
            ax.plot(x[valid_s], sos_smooth[valid_s], color="#2563eb", linewidth=1.8, zorder=3)
            lo = min(
                float(np.nanpercentile(sos_smooth[valid_s], 2)),
                float(np.nanpercentile(expected_model[valid_w], 2)) if np.any(valid_w) else float(np.nanpercentile(sos_smooth[valid_s], 2)),
            )
            hi = max(
                float(np.nanpercentile(sos_smooth[valid_s], 98)),
                float(np.nanpercentile(expected_model[valid_w], 98)) if np.any(valid_w) else float(np.nanpercentile(sos_smooth[valid_s], 98)),
            )
            pad = max((hi - lo) * 0.12, 15.0)
            ax.set_ylim(lo - pad, hi + pad)
            ax.set_xlim(float(np.nanmin(x[valid_s])), float(np.nanmax(x[valid_s])))

        ax.set_ylabel("SoS (m/s)", fontsize=10.5, color="#2563eb")
        ax.tick_params(axis="y", labelsize=8.5, colors="#2563eb", pad=2)
        ax.tick_params(axis="x", labelbottom=False)
        ax.spines["left"].set_color("#2563eb")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.grid(axis="y", color="#d1d5db", linewidth=0.6, alpha=0.6)
        ax.text(
            0.99,
            0.98,
            "Grey Line (dash) = Fluid Model",
            transform=ax.transAxes,
            ha="right",
            va="top",
            fontsize=8.3,
            color="#6b7280",
        )
        if np.isfinite(break_start_rev) and np.isfinite(break_end_rev) and break_end_rev > break_start_rev:
            ax.text(
                0.01,
                0.98,
                "Shaded = break from initial linear SoS trend",
                transform=ax.transAxes,
                ha="left",
                va="top",
                fontsize=8.0,
                color="#92400e",
            )

        ax_sig = fig.add_axes([inner_left, signal_bottom, inner_width, signal_h], facecolor="white", sharex=ax)
        self._draw_signal_strip(ax_sig, x, signal_level, (good_mask, marginal_mask, bad_mask), thresholds)

        labels = list(result.metrics.keys())
        values = []
        statuses = []

        for lab in labels:
            v, st, units = result.metrics[lab]
            statuses.append(st)
            if lab in {"Fluid Guess", "Est. Salinity"}:
                values.append(units)
            else:
                values.append(f"{float(v):.1f} {units}".rstrip() if np.isfinite(v) else "n/a")

        draw_metric_row(
            fig,
            left=inner_left,
            bottom=box_bottom,
            width=inner_width,
            height=box_h,
            labels=labels,
            values=values,
            statuses=statuses,
            gap_fraction=0.012,
            edgecolor="#9aa0a6",
            linewidth=1.0,
            value_fontsize=10.0,
            label_fontsize=8.2,
            value_fontweight="bold",
            label_fontweight="bold",
            text_color="#1f2937",
            label_color="#374151",
            show_markers=True,
            marker_radius=0.016,
            marker_color="#000000",
        )

        gas_at_head = result.plot_data.get("gas_at_head", False)
        if gas_at_head:
            fig.text(
                inner_left,
                signal_bottom - height * 0.016,
                "Possible gas / fluid level signature detected near the top of the run.",
                fontsize=8.2,
                color="#92400e",
                ha="left",
                va="top",
            )
