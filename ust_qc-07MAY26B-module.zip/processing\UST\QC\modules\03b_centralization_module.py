import numpy as np
from matplotlib.patches import FancyBboxPatch

from base import BaseModule, ModuleResult
from h5_utils import first_available, to_float_array


class CentralizationModule(BaseModule):
    name = "Centralization"

    def __init__(
        self,
        smooth_window=61,
        confidence_window=301,
        score_red_threshold=35.0,
        confidence_threshold=60.0,
        score_bad_percentiles=(60.0, 98.0),
        no_echo_floor=300.0,
        no_echo_relative_scale=0.35,
        no_echo_window=181,
    ):
        self.smooth_window = int(smooth_window)
        self.confidence_window = int(confidence_window)
        self.score_red_threshold = float(score_red_threshold)
        self.confidence_threshold = float(confidence_threshold)
        self.score_bad_percentiles = (
            float(score_bad_percentiles[0]),
            float(score_bad_percentiles[1]),
        )
        self.no_echo_floor = float(no_echo_floor)
        self.no_echo_relative_scale = float(no_echo_relative_scale)
        self.no_echo_window = int(no_echo_window)
        self.ecc_paths = [
            "main_sensor/eccentricity",
            "eccentricity",
        ]
        self.echo_paths = [
            "main_sensor/echo_peak_level",
            "echo_peak_level",
        ]
        self.noncirc_paths = [
            "main_sensor/non_circularity",
            "non_circularity",
        ]
        self.rev_paths = [
            "main_sensor/rev_number",
            "tool/rev_number",
            "rev_number",
        ]

    def _smooth_edge(self, x, w):
        x = np.asarray(x, dtype=float)
        if x.size == 0 or w <= 1:
            return x.copy()
        w = max(1, min(int(w), x.size))
        pad_left = w // 2
        pad_right = w - 1 - pad_left
        xpad = np.pad(x, (pad_left, pad_right), mode="edge")
        return np.convolve(xpad, np.ones(w) / w, mode="valid")

    def _normalize_badness(self, x, lo, hi):
        x = np.asarray(x, dtype=float)
        span = max(float(hi - lo), 1e-12)
        return np.clip((x - lo) / span, 0.0, 1.0)

    def _normalize_goodness(self, x, lo, hi):
        x = np.asarray(x, dtype=float)
        span = max(float(hi - lo), 1e-12)
        return np.clip((x - lo) / span, 0.0, 1.0)

    def compute(self, h5):
        ecc_path, ecc_data = first_available(h5, self.ecc_paths)
        echo_path, echo_data = first_available(h5, self.echo_paths)
        noncirc_path, noncirc_data = first_available(h5, self.noncirc_paths)
        rev_path, rev_data = first_available(h5, self.rev_paths)

        if ecc_data is None or echo_data is None:
            return ModuleResult(
                name=self.name,
                status="ERROR",
                messages=["Missing eccentricity and/or echo data"],
                metrics={},
                plot_data={},
            )

        ecc = to_float_array(ecc_data)
        echo = to_float_array(echo_data)
        if ecc.ndim != 2 or ecc.shape[1] < 2:
            return ModuleResult(name=self.name, status="ERROR", messages=["Eccentricity dataset must be Nx2"], metrics={}, plot_data={})
        if echo.ndim != 2 or echo.shape[1] < 4:
            return ModuleResult(name=self.name, status="ERROR", messages=["Echo level dataset must be NxM"], metrics={}, plot_data={})

        n = min(ecc.shape[0], echo.shape[0])
        if noncirc_data is not None:
            n = min(n, len(to_float_array(noncirc_data).reshape(-1)))
        if rev_data is not None:
            n = min(n, len(to_float_array(rev_data).reshape(-1)))

        ex = ecc[:n, 0]
        ey = ecc[:n, 1]
        echo = echo[:n, :]
        if noncirc_data is not None:
            noncirc = to_float_array(noncirc_data).reshape(-1)[:n]
        else:
            noncirc = np.zeros(n, dtype=float)
        if rev_data is not None:
            rev = to_float_array(rev_data).reshape(-1)[:n]
        else:
            rev = np.arange(n, dtype=float)

        finite = np.isfinite(ex) & np.isfinite(ey) & np.isfinite(noncirc) & np.isfinite(rev)
        finite &= np.all(np.isfinite(echo), axis=1)
        if not np.any(finite):
            return ModuleResult(name=self.name, status="ERROR", messages=["No finite centralization samples after alignment"], metrics={}, plot_data={})

        ex = ex[finite]
        ey = ey[finite]
        echo = echo[finite]
        noncirc = noncirc[finite]
        rev = rev[finite]

        ecc_mag = np.sqrt(ex * ex + ey * ey)
        echo_mean = np.mean(echo, axis=1)
        echo_peak = np.nanpercentile(echo, 90, axis=1)
        half = echo.shape[1] // 2
        if half > 0:
            opposite = np.mean(np.abs(echo[:, :half] - echo[:, half:half * 2]), axis=1)
        else:
            opposite = np.zeros_like(echo_mean)
        symmetry_ratio = opposite / (echo_mean + 1e-6)

        ecc_s = self._smooth_edge(ecc_mag, self.smooth_window)
        sym_s = self._smooth_edge(symmetry_ratio, self.smooth_window)
        echo_s = self._smooth_edge(echo_mean, self.smooth_window)
        echo_peak_s = self._smooth_edge(echo_peak, self.smooth_window)
        noncirc_s = self._smooth_edge(noncirc, self.smooth_window)

        score_lo, score_hi = self.score_bad_percentiles
        ecc_lo, ecc_hi = np.nanpercentile(ecc_s, [score_lo, score_hi])
        sym_lo, sym_hi = np.nanpercentile(sym_s, [score_lo, score_hi])
        noncirc_lo, noncirc_hi = np.nanpercentile(noncirc_s, [20, 95])
        echo_lo, echo_hi = np.nanpercentile(echo_s, [10, 90])
        sym_jitter = np.abs(symmetry_ratio - sym_s)
        jitter_lo, jitter_hi = np.nanpercentile(sym_jitter, [20, 95])

        no_echo_level = max(self.no_echo_floor, self.no_echo_relative_scale * echo_lo)
        echo_present_level = max(no_echo_level * 2.0, 0.70 * echo_lo)
        peak_present_level = max(no_echo_level * 2.5, 0.55 * echo_lo)

        low_echo_fraction = np.mean(echo <= no_echo_level, axis=1)
        low_echo_fraction_s = self._smooth_edge(low_echo_fraction, self.no_echo_window)
        mean_echo_bad = 1.0 - self._normalize_goodness(echo_s, no_echo_level, echo_present_level)
        peak_echo_bad = 1.0 - self._normalize_goodness(echo_peak_s, no_echo_level * 1.05, peak_present_level)
        no_echo_indicator = np.clip(
            0.55 * low_echo_fraction_s + 0.30 * mean_echo_bad + 0.15 * peak_echo_bad,
            0.0,
            1.0,
        )

        ecc_bad = self._normalize_badness(ecc_s, ecc_lo, ecc_hi)
        sym_bad = self._normalize_badness(sym_s, sym_lo, sym_hi)
        noncirc_bad = self._normalize_badness(noncirc_s, noncirc_lo, noncirc_hi)

        badness = np.clip(0.58 * ecc_bad + 0.42 * sym_bad, 0.0, 1.0)
        score = 100.0 * (1.0 - badness)
        score_no_echo_penalty = np.clip((no_echo_indicator - 0.25) / 0.75, 0.0, 1.0) ** 1.6
        score *= 1.0 - 0.90 * score_no_echo_penalty
        score = np.clip(score, 0.0, 100.0)

        echo_quality = self._normalize_goodness(echo_s, echo_lo, echo_hi)
        stability = 1.0 - self._normalize_badness(sym_jitter, jitter_lo, jitter_hi)
        confidence_raw = 100.0 * np.clip(0.55 * echo_quality + 0.25 * stability + 0.20 * (1.0 - noncirc_bad), 0.0, 1.0)
        confidence = self._smooth_edge(confidence_raw, self.confidence_window)
        confidence_no_echo_penalty = np.clip((np.maximum(no_echo_indicator, low_echo_fraction_s) - 0.15) / 0.85, 0.0, 1.0) ** 1.8
        confidence_cap = 100.0 - 90.0 * confidence_no_echo_penalty
        confidence = np.minimum(confidence, confidence_cap)
        confidence = np.clip(confidence, 0.0, 100.0)

        overall_score = float(np.nanmean(score))
        overall_conf = float(np.nanmean(confidence))
        red_mask = score < self.score_red_threshold
        time_red_pct = 100.0 * float(np.mean(red_mask)) if score.size else 0.0

        if overall_score >= 80.0:
            rating = "GOOD"
            status = "PASS"
        elif overall_score >= 60.0:
            rating = "FAIR"
            status = "WARN"
        else:
            rating = "POOR"
            status = "FAIL"

        conf_label = "HIGH" if overall_conf >= 75.0 else "MED" if overall_conf >= 55.0 else "LOW"

        longest_text = "No continuous low-score interval detected."
        if np.any(red_mask):
            idx = np.where(red_mask)[0]
            breaks = np.where(np.diff(idx) > 1)[0]
            starts = np.r_[idx[0], idx[breaks + 1]]
            ends = np.r_[idx[breaks], idx[-1]]
            lengths = ends - starts + 1
            k = int(np.argmax(lengths))
            longest_text = f"Longest continuous low-score interval: rev {rev[starts[k]]:.0f} to {rev[ends[k]]:.0f} ({int(lengths[k])} revs)."

        comment_b = longest_text

        return ModuleResult(
            name=self.name,
            status=status,
            messages=[
                f"Eccentricity source: {ecc_path}",
                f"Echo source: {echo_path}",
                f"Non-circularity source: {noncirc_path or 'not available'}",
            ],
            metrics={
                "Score": (overall_score, status, "/100"),
                "Confidence": (overall_conf, "INFO", "/100"),
                "Time in Red": (time_red_pct, status if time_red_pct > 15.0 else "INFO", "%"),
            },
            plot_data={
                "x": rev,
                "score": score,
                "confidence": confidence,
                "red_threshold": self.score_red_threshold,
                "confidence_threshold": self.confidence_threshold,
                "red_mask": red_mask,
                "overall_score": overall_score,
                "overall_confidence": overall_conf,
                "rating": rating,
                "confidence_label": conf_label,
                "time_red_pct": time_red_pct,
                "comment_b": comment_b,
                "no_echo_indicator": no_echo_indicator,
            },
        )

    def draw(self, fig, left, bottom, width, height, result: ModuleResult):
        header_h = height * 0.12
        plot_h = height * 0.55
        summary_h = height * 0.18
        pad_left = width * 0.075
        pad_right = width * 0.055
        inner_left = left + pad_left
        inner_width = width - pad_left - pad_right
        title_y = bottom + height - header_h * 0.58
        plot_bottom = bottom + summary_h + height * 0.09
        summary_bottom = bottom + height * 0.02

        fig.text(inner_left, title_y, "Centralization", fontsize=16, fontweight="bold", ha="left", va="center", color="#1f2937")

        if result.status == "ERROR" or not result.plot_data:
            ax = fig.add_axes([inner_left, plot_bottom, inner_width, plot_h], facecolor="#f7f7f7")
            ax.set_axis_off()
            ax.text(0.5, 0.55, "Centralization data unavailable", ha="center", va="center", fontsize=18, fontweight="bold", color="#6b7280")
            msgs = "\n".join(result.messages[:2]) if result.messages else "Missing centralization inputs"
            ax.text(0.5, 0.32, msgs, ha="center", va="center", fontsize=11, color="#6b7280")
            return

        x = np.asarray(result.plot_data.get("x", []), dtype=float)
        score = np.asarray(result.plot_data.get("score", []), dtype=float)
        confidence = np.asarray(result.plot_data.get("confidence", []), dtype=float)
        threshold = float(result.plot_data.get("red_threshold", 35.0))
        conf_threshold = float(result.plot_data.get("confidence_threshold", 60.0))
        red_mask = np.asarray(result.plot_data.get("red_mask", score < threshold), dtype=bool)

        ax = fig.add_axes([inner_left, plot_bottom, inner_width, plot_h], facecolor="white")
        ax.fill_between(x, 0.0, 100.0, where=red_mask, color="#efb0b0", alpha=0.40, linewidth=0)
        ax.plot(x, score, color="#2563eb", lw=1.6, zorder=3)
        ax.axhline(threshold, color="#2563eb", lw=0.8, ls=":", alpha=0.75, dash_capstyle="round")
        ax.set_ylim(0, 102)
        ax.set_ylabel("Score (%)", color="#2563eb", fontsize=10)
        ax.tick_params(axis="y", colors="#2563eb", labelsize=8.5, pad=1)
        ax.tick_params(axis="x", labelsize=8.5, pad=1)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

        ax2 = ax.twinx()
        ax2.plot(x, confidence, color="#b91c1c", lw=1.2, ls="--", alpha=0.95)
        ax2.axhline(conf_threshold, color="#b91c1c", lw=0.9, ls=":", alpha=0.75, dash_capstyle="round")
        ax2.set_ylim(0, 102)
        ax2.set_ylabel("Confidence (%)", color="#b91c1c", fontsize=10)
        ax2.tick_params(axis="y", colors="#b91c1c", labelsize=8.5, pad=1)
        ax2.spines["top"].set_visible(False)
        ax2.spines["right"].set_color("#b91c1c")

        summary_ax = fig.add_axes([inner_left, summary_bottom, inner_width, summary_h])
        summary_ax.set_axis_off()
        bg = FancyBboxPatch((0, 0), 1, 1, boxstyle="round,pad=0.012,rounding_size=0.015", fc="#f8fafc", ec="#d1d5db", lw=0.9)
        summary_ax.add_patch(bg)

        overall_score = result.plot_data.get("overall_score", np.nan)
        overall_conf = result.plot_data.get("overall_confidence", np.nan)
        rating = result.plot_data.get("rating", "")
        conf_label = result.plot_data.get("confidence_label", "")
        time_red_pct = result.plot_data.get("time_red_pct", np.nan)
        summary_ax.text(0.03, 0.66, f"Score: {overall_score:.0f}% | Confidence: {overall_conf:.0f}% | Low Score Volume: {time_red_pct:.1f}%", fontsize=10.2, ha="left", va="center", color="#374151")
        summary_ax.text(0.03, 0.28, result.plot_data.get("comment_b", ""), fontsize=10.0, ha="left", va="center", color="#4b5563")
