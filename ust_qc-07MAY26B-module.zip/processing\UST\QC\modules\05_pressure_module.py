import json
import os
from datetime import datetime
from pathlib import Path
import numpy as np

from base import BaseModule, ModuleResult
from h5_utils import first_available, to_float_array
from report_ui import draw_metric_row
from simulated_depth_export import _detect_pressure_segments


def _warning_intervals_from_mask(x, mask, min_points=3):
    x = np.asarray(x, dtype=float)
    mask = np.asarray(mask, dtype=bool)[: x.size]
    intervals = []
    start = None
    for idx, flag in enumerate(mask):
        if flag and start is None:
            start = idx
        if start is not None and ((not flag) or idx == len(mask) - 1):
            end = idx - 1 if not flag else idx
            if end - start + 1 >= min_points:
                intervals.append(
                    {
                        "start_rev": float(x[start]),
                        "end_rev": float(x[end]),
                    }
                )
            start = None
    return intervals


class PressureModule(BaseModule):
    name = "Pressure"

    def __init__(
        self,
        pressure_paths=None,
        timestamp_paths=None,
        rev_paths=None,
        temp_paths=None,
        welllogs_path="/mnt/data/WellLogs.json",
        wdl_dir="/mnt/data",
        aggregate_points=4,
        pressure_smooth_window=61,
        model_depth_ft=20.0,
    ):
        self.pressure_paths = pressure_paths or [
            "secondary_sensors/PT/pressure",
        ]
        self.timestamp_paths = timestamp_paths or [
            "secondary_sensors/PT/timestamp",
            "main_sensor/timestamp",
            "tool/timestamp",
        ]
        self.rev_paths = rev_paths or [
            "secondary_sensors/PT/rev_number",
            "main_sensor/rev_number",
            "tool/rev_number",
        ]
        self.temp_paths = temp_paths or [
            "secondary_sensors/PT/temperature",
        ]
        self.welllogs_path = welllogs_path
        self.wdl_dir = wdl_dir
        self.aggregate_points = max(1, int(aggregate_points))
        self.pressure_smooth_window = int(pressure_smooth_window)
        self.model_depth_ft = float(model_depth_ft)

    def _smooth_edge(self, x, w):
        x = np.asarray(x, dtype=float)
        if w <= 1 or x.size == 0:
            return x.copy()
        w = max(1, min(int(w), x.size))
        if w == 1:
            return x.copy()
        pad_left = w // 2
        pad_right = w - 1 - pad_left
        xpad = np.pad(x, (pad_left, pad_right), mode="edge")
        return np.convolve(xpad, np.ones(w) / w, mode="valid")

    def _aggregate_series(self, *arrays):
        arrs = [np.asarray(a, dtype=float) for a in arrays]
        npts = max(1, int(self.aggregate_points))
        if npts <= 1 or arrs[0].size < npts:
            return [a.copy() for a in arrs]
        n = (arrs[0].size // npts) * npts
        if n < npts:
            return [a.copy() for a in arrs]
        outs = []
        for arr in arrs:
            core = np.nanmean(arr[:n].reshape(-1, npts), axis=1)
            if n < arr.size:
                core = np.concatenate([core, [np.nanmean(arr[n:])]])
            outs.append(core)
        return outs

    def _nice_bound(self, x, direction="down"):
        if not np.isfinite(x):
            return float("nan")
        ax = abs(x)
        if ax >= 500:
            step = 25.0
        elif ax >= 100:
            step = 10.0
        elif ax >= 20:
            step = 5.0
        else:
            step = 1.0
        if direction == "down":
            return np.floor(x / step) * step
        return np.ceil(x / step) * step

    def _resolve_welllogs_path(self):
        candidates = [
            self.welllogs_path,
            os.environ.get("FUSION_WELLLOGS_JSON"),
        ]

        job_folder = os.environ.get("FUSION_JOB_FOLDER")
        if job_folder:
            candidates.append(str(Path(job_folder) / "WellLogs.json"))

        for candidate in candidates:
            if not candidate:
                continue
            path = Path(candidate)
            if path.is_file():
                return path
        return None

    def _resolve_wdl_path(self, welllogs_path, wdl_file):
        candidates = []

        job_folder = os.environ.get("FUSION_JOB_FOLDER")
        if job_folder:
            candidates.append(Path(job_folder) / wdl_file)

        preferred = os.environ.get("FUSION_WDL_FILE")
        if preferred:
            preferred_path = Path(preferred)
            if preferred_path.name == wdl_file:
                candidates.append(preferred_path)

        candidates.extend([
            welllogs_path.parent / wdl_file,
            Path(self.wdl_dir) / wdl_file,
        ])

        seen = set()
        for candidate in candidates:
            candidate = candidate.resolve()
            if candidate in seen:
                continue
            seen.add(candidate)
            if candidate.is_file():
                return candidate
        return None

    def _parse_wdl_start_time(self, info):
        raw = info.get("szLogStartTime")
        if not raw:
            return None
        for fmt in ("%d/%m/%Y %H:%M:%S", "%Y-%m-%d %H:%M:%S"):
            try:
                return datetime.strptime(raw, fmt)
            except ValueError:
                continue
        return None

    def _load_wdl_segments(self):
        try:
            welllogs_path = self._resolve_welllogs_path()
            if welllogs_path is None:
                return None

            with open(welllogs_path, "r", encoding="utf-8") as f:
                meta = json.load(f)
            if not isinstance(meta, dict) or not meta:
                return None

            segment_items = []
            for key, info in meta.items():
                if not isinstance(info, dict):
                    continue
                wdl_file = info.get("szInternalFilename", key)
                path = self._resolve_wdl_path(welllogs_path, wdl_file)
                if path is None:
                    continue
                start_dt = self._parse_wdl_start_time(info)
                segment_items.append((start_dt, key, info, path))

            if not segment_items:
                return None

            segment_items.sort(
                key=lambda item: (
                    1 if item[0] is None else 0,
                    item[0] or datetime.min,
                    item[1],
                )
            )

            known_starts = [item[0] for item in segment_items if item[0] is not None]
            base_start = min(known_starts) if known_starts else None
            sequential_offset = 0.0
            segments = []

            for start_dt, key, info, path in segment_items:
                rows = []
                with open(path, "r", encoding="utf-8", errors="ignore") as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        parts = [part.strip() for part in line.split(",") if part.strip()]
                        if len(parts) < 2:
                            continue
                        try:
                            rows.append((float(parts[0]), float(parts[1])))
                        except Exception:
                            continue
                if len(rows) < 3:
                    continue

                arr = np.array(rows, dtype=float)
                time_s = arr[:, 0]
                seconds_offset = float(info.get("wdSecondsOffset", 0.0))
                seconds_offset += 3600.0 * float(info.get("wdHoursOffset", 0.0))
                seconds_offset += 86400.0 * float(info.get("wdDaysOffset", 0.0))

                if start_dt is not None and base_start is not None:
                    section_offset = float((start_dt - base_start).total_seconds())
                else:
                    section_offset = sequential_offset

                rel_time_s = time_s - time_s[0] + seconds_offset + section_offset
                depth_m = arr[:, 1] + float(info.get("wdMetresOffset", 0.0))
                depth_ft = depth_m * 3.28084
                order = np.argsort(rel_time_s)
                rel_time_s = rel_time_s[order]
                depth_ft = depth_ft[order]
                uniq_t, idx = np.unique(rel_time_s, return_index=True)
                rel_time_s = uniq_t
                depth_ft = depth_ft[idx]
                segments.append(
                    {
                        "name": path.name,
                        "time_s": rel_time_s,
                        "depth_ft": depth_ft,
                    }
                )
                if rel_time_s.size:
                    sequential_offset = max(sequential_offset, float(np.nanmax(rel_time_s)))

            if not segments:
                return None

            return {
                "segments": segments,
                "welllogs_path": str(welllogs_path),
            }
        except Exception:
            return None

    def _estimate_depth_from_temp(self, rev, temp_c):
        temp_f = np.asarray(temp_c, dtype=float) * 9.0 / 5.0 + 32.0
        if rev.size < 3 or not np.any(np.isfinite(temp_f)):
            return np.full_like(rev, np.nan, dtype=float), np.nan
        temp_s = self._smooth_edge(temp_f, max(31, min(len(temp_f) // 2 * 2 + 1, 81)))
        try:
            fit_mask = np.isfinite(rev) & np.isfinite(temp_s)
            slope_f_per_rev, _ = np.polyfit(rev[fit_mask], temp_s[fit_mask], 1)
        except Exception:
            return np.full_like(rev, np.nan, dtype=float), np.nan
        geothermal_gradient_f_per_ft = 0.015
        if not np.isfinite(slope_f_per_rev) or abs(slope_f_per_rev) < 1e-6:
            return np.full_like(rev, np.nan, dtype=float), np.nan
        depth_per_rev = abs(slope_f_per_rev) / geothermal_gradient_f_per_ft
        pseudo_depth_ft = (rev[-1] - rev) * depth_per_rev
        return pseudo_depth_ft, depth_per_rev

    def _rolling_density_and_model(self, depth_ft, pressure_s, model_depth_ft):
        depth_ft = np.asarray(depth_ft, dtype=float)
        pressure_s = np.asarray(pressure_s, dtype=float)
        n = depth_ft.size
        density_local = np.full(n, np.nan)
        if n < 5:
            return density_local, np.full(n, np.nan), np.nan

        z_span = abs(depth_ft[0] - depth_ft[-1])
        if not np.isfinite(z_span) or z_span <= 1:
            return density_local, np.full(n, np.nan), np.nan

        for i in range(n):
            z0 = depth_ft[i]
            mask = np.abs(depth_ft - z0) <= (model_depth_ft / 2.0)
            if np.count_nonzero(mask) < 5:
                continue
            zwin = depth_ft[mask]
            pwin = pressure_s[mask]
            if not (np.all(np.isfinite(zwin)) and np.all(np.isfinite(pwin))):
                continue
            dz = abs(np.nanmax(zwin) - np.nanmin(zwin))
            if dz < 0.70 * model_depth_ft:
                continue
            try:
                m, b = np.polyfit(zwin, pwin, 1)
            except Exception:
                continue
            density_local[i] = abs(m) / 0.433

        if not np.any(np.isfinite(density_local)):
            return density_local, np.full(n, np.nan), np.nan

        est_density = float(np.nanmedian(density_local))
        if not np.isfinite(est_density):
            return density_local, np.full(n, np.nan), np.nan

        slope_mag = 0.433 * est_density
        if depth_ft[0] > depth_ft[-1]:
            expected = pressure_s[0] + slope_mag * (depth_ft - depth_ft[0])
        else:
            expected = pressure_s[0] - slope_mag * (depth_ft - depth_ft[0])
        return density_local, expected, est_density

    def _movement_threshold(self, rev_seg, pressure_seg):
        rev_seg = np.asarray(rev_seg, dtype=float)
        pressure_seg = np.asarray(pressure_seg, dtype=float)
        if rev_seg.size < 3:
            return np.nan
        grad = np.gradient(pressure_seg, rev_seg)
        abs_grad = np.abs(grad[np.isfinite(grad)])
        if abs_grad.size == 0:
            return np.nan
        pressure_span = abs(float(pressure_seg[-1] - pressure_seg[0]))
        rev_span = max(abs(float(rev_seg[-1] - rev_seg[0])), 1.0)
        return max(
            float(np.nanpercentile(abs_grad, 60)),
            (pressure_span / rev_span) * 0.25,
        )

    def _detect_stationary_windows(self, rev, pressure_s, segment, threshold):
        start_idx = int(segment["start_idx"])
        end_idx = int(segment["end_idx"])
        rev_seg = np.asarray(rev[start_idx:end_idx + 1], dtype=float)
        pressure_seg = np.asarray(pressure_s[start_idx:end_idx + 1], dtype=float)
        if rev_seg.size < 6 or not np.isfinite(threshold) or threshold <= 0:
            return []

        grad = np.gradient(pressure_seg, rev_seg)
        stationary = np.abs(grad) <= (threshold * 0.35)
        min_points = max(4, min(12, rev_seg.size // 12))
        windows = []
        run_start = None
        for idx, flag in enumerate(stationary):
            if flag and run_start is None:
                run_start = idx
            if run_start is not None and ((not flag) or idx == stationary.size - 1):
                run_end = idx - 1 if not flag else idx
                if run_end - run_start + 1 >= min_points:
                    pressure_change = abs(float(pressure_seg[run_end] - pressure_seg[run_start]))
                    rev_span = abs(float(rev_seg[run_end] - rev_seg[run_start]))
                    if pressure_change <= max(5.0, abs(float(pressure_seg[-1] - pressure_seg[0])) * 0.03) and rev_span >= 60.0:
                        windows.append(
                            {
                                "start_idx": start_idx + run_start,
                                "end_idx": start_idx + run_end,
                                "start_rev": float(rev_seg[run_start]),
                                "end_rev": float(rev_seg[run_end]),
                                "pressure_change_psi": float(pressure_seg[run_end] - pressure_seg[run_start]),
                            }
                        )
                run_start = None
        return windows

    def _segment_expected_model(self, rev, depth_ft, pressure_s, est_density, segments):
        depth_ft = np.asarray(depth_ft, dtype=float)
        pressure_s = np.asarray(pressure_s, dtype=float)
        expected = np.full(depth_ft.shape, np.nan, dtype=float)
        stationary_windows = []
        if not np.isfinite(est_density):
            return expected, stationary_windows

        slope_mag = 0.433 * float(est_density)
        if not segments:
            return expected, stationary_windows

        for segment in segments:
            start_rev = float(segment["start_rev"])
            end_rev = float(segment["end_rev"])
            seg_mask = (rev >= start_rev) & (rev <= end_rev)
            if np.count_nonzero(seg_mask) < 5:
                continue
            start_idx = int(np.flatnonzero(seg_mask)[0])
            end_idx = int(np.flatnonzero(seg_mask)[-1])
            rev_seg = rev[start_idx:end_idx + 1]
            depth_seg = depth_ft[start_idx:end_idx + 1]
            pressure_seg = pressure_s[start_idx:end_idx + 1]
            threshold = self._movement_threshold(rev_seg, pressure_seg)
            seg_windows = self._detect_stationary_windows(rev, pressure_s, segment, threshold)
            stationary_windows.extend(seg_windows)

            moving_ranges = []
            cursor = start_idx
            for window in seg_windows:
                if cursor <= window["start_idx"] - 1:
                    moving_ranges.append((cursor, window["start_idx"] - 1))
                expected[window["start_idx"]:window["end_idx"] + 1] = pressure_s[window["start_idx"]]
                cursor = window["end_idx"] + 1
            if cursor <= end_idx:
                moving_ranges.append((cursor, end_idx))

            for move_start, move_end in moving_ranges:
                if move_end - move_start + 1 < 3:
                    continue
                move_depth = depth_ft[move_start:move_end + 1]
                move_pressure = pressure_s[move_start:move_end + 1]
                if move_depth[0] > move_depth[-1]:
                    expected[move_start:move_end + 1] = move_pressure[0] + slope_mag * (move_depth - move_depth[0])
                else:
                    expected[move_start:move_end + 1] = move_pressure[0] - slope_mag * (move_depth - move_depth[0])

        return expected, stationary_windows

    def compute(self, h5):
        pressure_path, pressure_data = first_available(h5, self.pressure_paths)
        time_path, time_data = first_available(h5, self.timestamp_paths)
        rev_path, rev_data = first_available(h5, self.rev_paths)
        temp_path, temp_data = first_available(h5, self.temp_paths)

        if pressure_data is None or time_data is None or rev_data is None:
            return ModuleResult(name=self.name, status="ERROR", messages=["Pressure, timestamp, or revolution data missing"], metrics={}, plot_data={})

        pressure = to_float_array(pressure_data).reshape(-1)
        ts = to_float_array(time_data).reshape(-1)
        rev = to_float_array(rev_data).reshape(-1)
        temp_c = to_float_array(temp_data).reshape(-1) if temp_data is not None else np.full_like(pressure, np.nan)

        n = min(len(pressure), len(ts), len(rev), len(temp_c))
        pressure, ts, rev, temp_c = pressure[:n], ts[:n], rev[:n], temp_c[:n]
        valid = np.isfinite(pressure) & np.isfinite(ts) & np.isfinite(rev)
        if not np.any(valid):
            return ModuleResult(name=self.name, status="ERROR", messages=["No finite pressure samples after alignment"], metrics={}, plot_data={})
        pressure, ts, rev, temp_c = pressure[valid], ts[valid], rev[valid], temp_c[valid]
        order = np.argsort(ts)
        pressure, ts, rev, temp_c = pressure[order], ts[order], rev[order], temp_c[order]
        uniq_t, idx = np.unique(ts, return_index=True)
        pressure, rev, temp_c = pressure[idx], rev[idx], temp_c[idx]
        ts = uniq_t

        depth_source = 'Estimated depth'
        depth_messages = []
        depth_info = self._load_wdl_segments()
        if depth_info is not None:
            rel_ts = ts - ts[0]
            depth_ft = np.full(rel_ts.shape, np.nan, dtype=float)
            segment_ranges = []
            covered_points = 0
            for segment in depth_info["segments"]:
                seg_t = segment["time_s"]
                seg_depth = segment["depth_ft"]
                if seg_t.size < 3:
                    continue
                mask = (rel_ts >= np.nanmin(seg_t)) & (rel_ts <= np.nanmax(seg_t))
                count = int(np.count_nonzero(mask))
                if count < 50:
                    continue
                depth_ft[mask] = np.interp(rel_ts[mask], seg_t, seg_depth)
                covered_points += count
                segment_ranges.append((segment["name"], float(rev[mask][0]), float(rev[mask][-1])))

            if np.count_nonzero(np.isfinite(depth_ft)) >= 50:
                depth_source = 'Merged WDL depth'
                depth_messages.append(f"WDL segments used: {', '.join(segment['name'] for segment in depth_info['segments'])}")
                depth_messages.append(f"WDL-aligned pressure samples: {covered_points}")
                if segment_ranges:
                    ranges_text = ", ".join(
                        f"{name} rev {start_rev:.0f}-{end_rev:.0f}" for name, start_rev, end_rev in segment_ranges
                    )
                    depth_messages.append(f"WDL coverage by segment: {ranges_text}")
            else:
                depth_ft, _ = self._estimate_depth_from_temp(rev, temp_c)
        else:
            depth_ft, _ = self._estimate_depth_from_temp(rev, temp_c)

        depth_valid = np.isfinite(depth_ft)
        if not np.all(depth_valid):
            pressure, ts, rev, temp_c, depth_ft = (
                pressure[depth_valid],
                ts[depth_valid],
                rev[depth_valid],
                temp_c[depth_valid],
                depth_ft[depth_valid],
            )

        if pressure.size < 10:
            return ModuleResult(name=self.name, status="ERROR", messages=["Pressure module needs at least 10 samples"], metrics={}, plot_data={})

        rev, depth_ft, pressure, ts = self._aggregate_series(rev, depth_ft, pressure, ts)
        valid2 = np.isfinite(rev) & np.isfinite(pressure) & np.isfinite(depth_ft)
        rev, depth_ft, pressure, ts = rev[valid2], depth_ft[valid2], pressure[valid2], ts[valid2]
        if rev.size < 10:
            return ModuleResult(name=self.name, status="ERROR", messages=["Depth alignment unavailable"], metrics={}, plot_data={})

        order = np.argsort(rev)
        rev, depth_ft, pressure, ts = rev[order], depth_ft[order], pressure[order], ts[order]

        pressure_s = self._smooth_edge(pressure, self.pressure_smooth_window)
        density_local, expected_global, est_density = self._rolling_density_and_model(depth_ft, pressure_s, self.model_depth_ft)
        movement_segments = _detect_pressure_segments(rev, pressure)
        expected, stationary_windows = self._segment_expected_model(rev, depth_ft, pressure_s, est_density, movement_segments)
        if not np.any(np.isfinite(expected)):
            expected = expected_global
        residual = pressure_s - expected
        residual = residual - (float(np.nanmedian(residual)) if np.any(np.isfinite(residual)) else 0.0)
        residual_s = self._smooth_edge(np.nan_to_num(residual, nan=0.0), max(9, self.pressure_smooth_window // 3))
        residual_s[~np.isfinite(residual)] = np.nan

        min_pressure = float(np.nanmin(pressure_s)) if np.any(np.isfinite(pressure_s)) else float('nan')
        max_pressure = float(np.nanmax(pressure_s)) if np.any(np.isfinite(pressure_s)) else float('nan')
        p5 = float(np.nanpercentile(pressure_s, 5)) if np.any(np.isfinite(pressure_s)) else float('nan')
        p95 = float(np.nanpercentile(pressure_s, 95)) if np.any(np.isfinite(pressure_s)) else float('nan')
        span90 = p95 - p5 if np.isfinite(p95 - p5) else np.nan
        total_span = span90 / 0.90 if np.isfinite(span90) and span90 > 0 else 10.0
        pad = 0.05 * total_span
        lower_scale = self._nice_bound(min(p5 - pad, min_pressure), 'down')
        upper_scale = self._nice_bound(max(p95 + pad, max_pressure), 'up')

        residual_p95 = float(np.nanpercentile(np.abs(residual_s), 95)) if np.any(np.isfinite(residual_s)) else float('nan')
        residual_warn_limit = max(5.0, min(15.0, total_span * 0.08))
        residual_warn_mask = np.isfinite(residual_s) & (np.abs(residual_s) >= residual_warn_limit)
        warning_intervals = _warning_intervals_from_mask(rev, residual_warn_mask, min_points=max(3, min(8, rev.size // 250)))
        status = "WARN" if warning_intervals else "INFO"

        return ModuleResult(
            name=self.name,
            status=status,
            messages=[
                f'Pressure source: {pressure_path}',
                f'Timestamp source: {time_path}',
                f'Rev source: {rev_path}',
                f'Depth source used for model: {depth_source}',
                *depth_messages,
                *[
                    f"Movement segment {segment['index']}: {segment['trend']} rev {segment['start_rev']:.0f}-{segment['end_rev']:.0f} "
                    f"({segment['start_pressure_psi']:.1f} psi to {segment['end_pressure_psi']:.1f} psi)"
                    for segment in movement_segments
                ],
                *[
                    f"Stationary window: rev {window['start_rev']:.0f}-{window['end_rev']:.0f} "
                    f"(pressure drift {window['pressure_change_psi']:.1f} psi)"
                    for window in stationary_windows
                ],
                f'Grey Line = Hydrostatic Model ({self.model_depth_ft:.0f} ft density fit)',
                f'Residual P95: {residual_p95:.2f} psi' if np.isfinite(residual_p95) else 'Residual P95 unavailable',
                *[
                    f"Pressure warning interval: rev {interval['start_rev']:.0f}-{interval['end_rev']:.0f}"
                    for interval in warning_intervals[:4]
                ],
            ],
            metrics={
                'Max Pressure': (max_pressure, 'INFO', 'psi'),
                'Lower Scale': (lower_scale, 'INFO', 'psi'),
                'Upper Scale': (upper_scale, 'INFO', 'psi'),
                'Est. Fluid Density': (est_density, 'INFO', 'g/cc'),
            },
            plot_data={
                'x': rev,
                'pressure': pressure,
                'pressure_s': pressure_s,
                'expected': expected,
                'residual': residual_s,
                'residual_limit': residual_p95 if np.isfinite(residual_p95) and residual_p95 > 0 else 5.0,
                'residual_warning_limit': residual_warn_limit,
                'warning_intervals': warning_intervals,
                'axis_label': 'Revolution #',
            },
        )

    def draw(self, fig, left, bottom, width, height, result: ModuleResult):
        header_h = height * 0.10
        plot_zone_h = height * 0.58
        xband_h = height * 0.07
        box_zone_h = height * 0.25
        pad_left = width * 0.075
        pad_right = width * 0.055
        inner_left = left + pad_left
        inner_width = width - pad_left - pad_right
        title_y = bottom + height - header_h * 0.58
        plot_bottom = bottom + box_zone_h + xband_h + height * 0.03
        plot_h = plot_zone_h - height * 0.04
        boxes_bottom = bottom + height * 0.035
        boxes_h = box_zone_h - height * 0.08

        fig.text(inner_left, title_y, 'Pressure', fontsize=16, fontweight='bold', ha='left', va='center', color='#1f2937')

        if result.status == 'ERROR' or not result.plot_data:
            ax = fig.add_axes([inner_left, bottom + box_zone_h + 0.04 * height, inner_width, plot_zone_h + xband_h - 0.08 * height], facecolor='#f7f7f7')
            ax.set_axis_off()
            ax.text(0.5, 0.58, 'Pressure data unavailable', ha='center', va='center', fontsize=16, fontweight='bold', color='#6b7280')
            msg = '\n'.join(result.messages[:3]) if result.messages else 'No details'
            ax.text(0.5, 0.32, msg, ha='center', va='center', fontsize=10, color='#6b7280')
            return

        ax = fig.add_axes([inner_left, plot_bottom, inner_width, plot_h], facecolor='white')
        x = np.asarray(result.plot_data.get('x', []), dtype=float)
        pressure = np.asarray(result.plot_data.get('pressure', []), dtype=float)
        pressure_s = np.asarray(result.plot_data.get('pressure_s', []), dtype=float)
        expected = np.asarray(result.plot_data.get('expected', []), dtype=float)
        residual = np.asarray(result.plot_data.get('residual', []), dtype=float)
        warning_intervals = result.plot_data.get('warning_intervals', [])

        for interval in warning_intervals:
            try:
                ax.axvspan(float(interval["start_rev"]), float(interval["end_rev"]), color="#efe3a6", alpha=0.35, zorder=0)
            except Exception:
                continue

        valid = np.isfinite(x) & np.isfinite(pressure)
        if np.any(valid):
            ax.plot(x[valid], pressure[valid], linewidth=0.9, color='#93c5fd', alpha=0.8)
        valids = np.isfinite(x) & np.isfinite(pressure_s)
        if np.any(valids):
            ax.plot(x[valids], pressure_s[valids], linewidth=1.4, color='#2563eb')
        validm = np.isfinite(x) & np.isfinite(expected)
        if np.any(validm):
            ax.plot(x[validm], expected[validm], linewidth=1.0, color='#808080', linestyle='--')
            ax.text(0.985, 0.98, 'Grey Line = Hydrostatic Model', transform=ax.transAxes,
                    ha='right', va='top', fontsize=8.6, color='#4b5563')
        if np.any(valids):
            lo = float(np.nanpercentile(pressure_s[valids], 5))
            hi = float(np.nanpercentile(pressure_s[valids], 95))
            pad = max((hi - lo) * 0.08, 3.0)
            ax.set_ylim(lo - pad, hi + pad)
        ax.set_ylabel('Pressure (psi)', fontsize=10.5, color='#2563eb')
        ax.tick_params(axis='y', labelsize=8.5, colors='#2563eb', pad=2)
        ax.tick_params(axis='x', labelsize=8.5, colors='#111827', pad=6)
        ax.spines['left'].set_color('#2563eb')
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.set_xlabel('')
        if x.size:
            ax.set_xlim(np.nanmin(x), np.nanmax(x))

        validr = np.isfinite(x) & np.isfinite(residual)
        if np.any(validr):
            ax2 = ax.twinx()
            ax2.plot(x[validr], residual[validr], linewidth=1.2, color='#d94841', linestyle='--', alpha=0.95)
            r95 = float(np.nanpercentile(np.abs(residual[validr]), 95))
            ylim = max(r95 * 1.25, 5.0)
            ax2.set_ylim(-ylim, ylim)
            ax2.axhline(0.0, color='#d94841', linewidth=0.9, linestyle=':', alpha=0.75)
            ax2.set_ylabel('Hydrostatic Deviation (psi)', fontsize=10.5, color='#d94841', labelpad=10)
            ax2.tick_params(axis='y', labelsize=8.5, colors='#d94841', pad=2)
            ax2.spines['top'].set_visible(False)
            ax2.spines['right'].set_color('#d94841')
        labels = list(result.metrics.keys())
        values = []
        statuses = []
        for k in labels:
            v, s, units = result.metrics[k]
            if np.isfinite(v):
                if units == 'g/cc':
                    values.append(f'{v:.2f} {units}')
                else:
                    values.append(f'{v:.1f} {units}')
            else:
                values.append('n/a')
            statuses.append(s)

        def pressure_density_fill(val, status):
            if val == 'n/a':
                return None
            try:
                num = float(str(val).split()[0])
            except Exception:
                return None
            if 0.95 <= num <= 1.25:
                return '#b8d3b8'
            if 0.80 <= num <= 1.45:
                return '#efe3a6'
            return '#efb0b0'

        draw_metric_row(
            fig,
            left=inner_left,
            bottom=boxes_bottom,
            width=inner_width,
            height=boxes_h,
            labels=labels,
            values=values,
            statuses=statuses,
            gap_fraction=0.014,
            edgecolor='#9aa0a6',
            linewidth=1.0,
            value_fontsize=10.0,
            label_fontsize=8.4,
            value_fontweight='bold',
            label_fontweight='bold',
            text_color='#1f2937',
            label_color='#374151',
            fill_overrides={'Est. Fluid Density': pressure_density_fill},
            show_markers=True,
            marker_radius=0.016,
            marker_color='#000000',
        )
