
import numpy as np

from base import BaseModule, ModuleResult
from h5_utils import first_available, to_float_array
from report_ui import draw_metric_row

DEFAULT_STALL_TORQUE_MNM = 60.0
NORMAL_TORQUE_MAX_MNM = 35.0
WARNING_TORQUE_MAX_MNM = 55.0


class DriveStatusModule(BaseModule):
    name = "Motor"

    def __init__(
        self,
        rpm_target=160.0,
        stall_torque_mNm=DEFAULT_STALL_TORQUE_MNM,
        rpm_smooth=31,
        torque_smooth=101,
        rolling_window=101,
        warn_load_pct=50.0,
        fail_load_pct=(WARNING_TORQUE_MAX_MNM / DEFAULT_STALL_TORQUE_MNM) * 100.0,
        warn_rpm_loss=1.0,
        fail_rpm_loss=2.0,
        warn_rpm_std=0.75,
        fail_rpm_std=1.25,
        min_event_len=10,
    ):
        self.rpm_target = float(rpm_target)
        self.stall_torque_mNm = float(stall_torque_mNm)
        self.rpm_smooth = int(rpm_smooth)
        self.torque_smooth = int(torque_smooth)
        self.rolling_window = int(rolling_window)
        self.warn_load_pct = float(warn_load_pct)
        self.fail_load_pct = float(fail_load_pct)
        self.warn_rpm_loss = float(warn_rpm_loss)
        self.fail_rpm_loss = float(fail_rpm_loss)
        self.warn_rpm_std = float(warn_rpm_std)
        self.fail_rpm_std = float(fail_rpm_std)
        self.min_event_len = int(min_event_len)

        self.rpm_paths = ["tool/rotating_head_speed", "tool/rpm", "rotating_head_speed", "rpm"]
        self.torque_paths = ["tool/motor_torque", "tool/torque", "motor_torque", "torque"]
        self.rev_paths = ["tool/rev_number", "main_sensor/rev_number", "secondary_sensors/PT/rev_number", "secondary_sensors/TOF/rev_number", "rev_number"]

    def _smooth_edge(self, x, w):
        x = np.asarray(x, dtype=float)
        if w <= 1 or x.size == 0:
            return x.copy()
        w = max(1, min(int(w), x.size))
        pad_left = w // 2
        pad_right = w - 1 - pad_left
        xpad = np.pad(x, (pad_left, pad_right), mode="edge")
        return np.convolve(xpad, np.ones(w) / w, mode="valid")

    def _rolling_std(self, x, w):
        x = np.asarray(x, dtype=float)
        if x.size == 0:
            return x.copy()
        w = max(3, min(int(w), x.size))
        if w >= x.size:
            return np.full_like(x, np.nanstd(x))
        c1 = np.cumsum(np.insert(x, 0, 0.0))
        c2 = np.cumsum(np.insert(x * x, 0, 0.0))
        sw = c1[w:] - c1[:-w]
        s2w = c2[w:] - c2[:-w]
        mw = sw / w
        vw = np.maximum(s2w / w - mw * mw, 0.0)
        out = np.sqrt(vw)
        pad_left = w // 2
        pad_right = x.size - out.size - pad_left
        return np.pad(out, (pad_left, pad_right), mode="edge")

    def _extract_intervals(self, mask, x):
        mask = np.asarray(mask, dtype=bool)
        x = np.asarray(x, dtype=float)
        intervals = []
        start = None
        for i, flag in enumerate(mask):
            if flag and start is None:
                start = i
            if start is not None and ((not flag) or i == len(mask) - 1):
                end = i if not flag else i + 1
                if end - start >= self.min_event_len:
                    intervals.append((x[start], x[end - 1], start, end))
                start = None
        return intervals

    def compute(self, h5):
        rpm_path, rpm_data = first_available(h5, self.rpm_paths)
        tq_path, tq_data = first_available(h5, self.torque_paths)
        rev_path, rev_data = first_available(h5, self.rev_paths)
        if rpm_data is None or tq_data is None or rev_data is None:
            return ModuleResult(name=self.name, status="ERROR", messages=["Missing RPM, torque, or revolution dataset"], metrics={}, plot_data={})

        rpm = to_float_array(rpm_data).reshape(-1)
        tq = to_float_array(tq_data).reshape(-1)
        rev = to_float_array(rev_data).reshape(-1)
        n = min(len(rpm), len(tq), len(rev))
        rpm, tq, rev = rpm[:n], tq[:n], rev[:n]
        valid = np.isfinite(rpm) & np.isfinite(tq) & np.isfinite(rev)
        rpm, tq, rev = rpm[valid], tq[valid], rev[valid]
        if len(rev) < 10:
            return ModuleResult(name=self.name, status="ERROR", messages=["Not enough finite samples"], metrics={}, plot_data={})

        order = np.argsort(rev)
        rpm, tq, rev = rpm[order], tq[order], rev[order]
        tq_mNm = tq * 1000.0 if np.nanmax(np.abs(tq)) < 1.0 else tq.copy()

        rpm_s = self._smooth_edge(rpm, self.rpm_smooth)
        tq_s = self._smooth_edge(tq_mNm, self.torque_smooth)
        rpm_loss = np.maximum(self.rpm_target - rpm_s, 0.0)
        rpm_std = self._rolling_std(rpm_s, self.rolling_window)
        load_pct = 100.0 * tq_s / self.stall_torque_mNm

        warn_mask = (load_pct >= self.warn_load_pct) & ((rpm_loss >= self.warn_rpm_loss) | (rpm_std >= self.warn_rpm_std))
        fail_mask = (load_pct >= self.fail_load_pct) & ((rpm_loss >= self.fail_rpm_loss) | (rpm_std >= self.fail_rpm_std))
        warn_intervals = self._extract_intervals(warn_mask, rev)
        fail_intervals = self._extract_intervals(fail_mask, rev)

        peak_load = float(np.nanmax(load_pct))
        peak_rpm_loss = float(np.nanmax(rpm_loss))
        peak_rpm_std = float(np.nanmax(rpm_std))
        warn_torque_mNm = self.stall_torque_mNm * self.warn_load_pct / 100.0
        fail_torque_mNm = self.stall_torque_mNm * self.fail_load_pct / 100.0

        if fail_intervals or peak_load > self.fail_load_pct:
            drive_status = "FAIL"
        elif warn_intervals or peak_load > self.warn_load_pct:
            drive_status = "WARN"
        else:
            drive_status = "PASS"

        metrics = {
            "Peak Load": (
                peak_load,
                "PASS" if peak_load <= self.warn_load_pct else "WARN" if peak_load <= self.fail_load_pct else "FAIL",
                "%",
            ),
            "Peak RPM Loss": (peak_rpm_loss, "PASS" if peak_rpm_loss <= 1.0 else "WARN" if peak_rpm_loss <= 2.0 else "FAIL", "RPM"),
            "Peak RPM Stdev": (peak_rpm_std, "PASS" if peak_rpm_std <= 0.75 else "WARN" if peak_rpm_std <= 1.25 else "FAIL", "RPM"),
            "Correlated Events": (len(warn_intervals) + len(fail_intervals), drive_status, ""),
        }

        warning_intervals = [
            {"start_rev": float(x0), "end_rev": float(x1)}
            for x0, x1, _, _ in warn_intervals
        ]
        fail_warning_intervals = [
            {"start_rev": float(x0), "end_rev": float(x1)}
            for x0, x1, _, _ in fail_intervals
        ]

        return ModuleResult(
            name=self.name,
            status=drive_status,
            messages=[
                f"RPM source: {rpm_path}",
                f"Torque source: {tq_path}",
                f"Target RPM: {self.rpm_target:.0f}",
                f"Stall torque basis: {self.stall_torque_mNm:.0f} mN.m",
                f"Torque thresholds: normal <= {warn_torque_mNm:.0f} mN.m, warn <= {fail_torque_mNm:.0f} mN.m, fail > {fail_torque_mNm:.0f} mN.m",
                "Intervals are shaded when torque and RPM degradation exceed the correlation thresholds.",
            ],
            metrics=metrics,
            plot_data={
                "x": rev,
                "load_pct": load_pct,
                "rpm_loss": rpm_loss,
                "rpm_std": rpm_std,
                "warn_intervals": warn_intervals,
                "fail_intervals": fail_intervals,
                "warning_intervals": fail_warning_intervals or warning_intervals,
            },
        )

    def draw(self, fig, left, bottom, width, height, result: ModuleResult):
        header_h = height * 0.10
        plot_zone_h = height * 0.55
        xband_h = height * 0.05
        box_zone_h = height * 0.30
        pad_left = width * 0.075
        pad_right = width * 0.055
        inner_left = left + pad_left
        inner_width = width - pad_left - pad_right
        title_y = bottom + height - header_h * 0.58
        plot_bottom = bottom + box_zone_h + xband_h + height * 0.025
        plot_h = plot_zone_h - height * 0.055
        boxes_bottom = bottom + height * 0.035
        boxes_h = box_zone_h - height * 0.09

        fig.text(inner_left, title_y, "Motor", fontsize=16, fontweight="bold", ha="left", va="center", color="#1f2937")
        fig.text(inner_left + inner_width, title_y, "Torque vs RPM correlation", fontsize=10, ha="right", va="center", color="#4b5563")

        if result.status == "ERROR" or not result.plot_data:
            ax = fig.add_axes([inner_left, bottom + box_zone_h + 0.04 * height, inner_width, plot_zone_h + xband_h - 0.08 * height], facecolor="#f7f7f7")
            ax.set_axis_off()
            ax.text(0.5, 0.58, "Motor data unavailable", ha="center", va="center", fontsize=16, fontweight="bold", color="#6b7280")
            msg = "\n".join(result.messages[:3]) if result.messages else "No details"
            ax.text(0.5, 0.32, msg, ha="center", va="center", fontsize=10, color="#6b7280")
            return

        ax = fig.add_axes([inner_left, plot_bottom, inner_width, plot_h], facecolor="white")
        x = np.asarray(result.plot_data.get("x", []), dtype=float)
        rpm_loss = np.asarray(result.plot_data.get("rpm_loss", []), dtype=float)
        load_pct = np.asarray(result.plot_data.get("load_pct", []), dtype=float)

        for x0, x1, _, _ in result.plot_data.get("warn_intervals", []):
            ax.axvspan(x0, x1, color="#efe3a6", alpha=0.35, zorder=0)
        for x0, x1, _, _ in result.plot_data.get("fail_intervals", []):
            ax.axvspan(x0, x1, color="#efb0b0", alpha=0.35, zorder=0)

        valid_l = np.isfinite(x) & np.isfinite(rpm_loss)
        if np.any(valid_l):
            ax.plot(x[valid_l], rpm_loss[valid_l], linewidth=1.1, color="#2563eb")
        ax.set_ylabel("RPM Loss", fontsize=10.5, color="#2563eb")
        ax.tick_params(axis="y", labelsize=8.5, colors="#2563eb", pad=2)
        ax.tick_params(axis="x", labelsize=8.5, colors="#111827", pad=2)
        ax.spines["left"].set_color("#2563eb")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ylim = max(1.5, float(np.nanmax(rpm_loss) * 1.15) if np.any(valid_l) else 1.5)
        ax.set_ylim(0, ylim)
        ax.axhline(1.0, linestyle=":", linewidth=0.8, color="#2563eb", alpha=0.75)
        ax.axhline(2.0, linestyle=":", linewidth=0.8, color="#2563eb", alpha=0.75)

        ax2 = ax.twinx()
        valid_r = np.isfinite(x) & np.isfinite(load_pct)
        if np.any(valid_r):
            ax2.plot(x[valid_r], load_pct[valid_r], linewidth=1.2, color="#d94841", linestyle="--")
        ax2.set_ylabel("Torque (% stall)", fontsize=10.5, color="#d94841", labelpad=10)
        ax2.tick_params(axis="y", labelsize=8.5, colors="#d94841", pad=2)
        ax2.spines["top"].set_visible(False)
        ax2.spines["right"].set_color("#d94841")
        ax2.set_ylim(0, max(100.0, float(np.nanmax(load_pct) * 1.20) if np.any(valid_r) else 100.0))
        ax2.axhline(self.warn_load_pct, linestyle=":", linewidth=0.8, color="#d94841", alpha=0.55)
        ax2.axhline(self.fail_load_pct, linestyle=":", linewidth=0.9, color="#d94841", alpha=0.85)
        labels = list(result.metrics.keys())
        values = []
        statuses = []
        for lab in labels:
            v, st, units = result.metrics[lab]
            statuses.append(st)
            if isinstance(v, (int, np.integer)) or (isinstance(v, float) and units == ""):
                val = f"{int(v)}" if units == "" else f"{int(v)} {units}"
            else:
                val = f"{float(v):.1f} {units}".rstrip()
            values.append(val)

        draw_metric_row(
            fig,
            left=inner_left,
            bottom=boxes_bottom,
            width=inner_width,
            height=boxes_h,
            labels=labels,
            values=values,
            statuses=statuses,
            gap_fraction=0.014,
            edgecolor="#9aa0a6",
            linewidth=1.0,
            value_fontsize=10.2,
            label_fontsize=8.5,
            value_fontweight="bold",
            label_fontweight="bold",
            text_color="#1f2937",
            label_color="#374151",
            show_markers=True,
            marker_radius=0.016,
            marker_color="#000000",
        )
