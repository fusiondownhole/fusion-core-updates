import os
import tempfile
from datetime import datetime, timedelta, timezone

import numpy as np
from matplotlib import pyplot as plt
from matplotlib.image import imread
from matplotlib.patches import Circle

from base import BaseModule, ModuleResult
from h5_utils import has_dataset, get_dataset, to_float_array
from confidence_model import compute_confidence
from report_ui import draw_status_row
from runtime_paths import resource_path
from build_info import UST_QC_BUILD_LABEL

try:
    import config_parser as _config_parser
except ModuleNotFoundError:
    _config_parser = None


def _parse_config_txt(path):
    if _config_parser is not None:
        return _config_parser.parse_config_txt(path)

    result = {}
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for raw_line in f:
            line = raw_line.strip()
            if not line:
                continue

            if "=" in line:
                key, value = line.split("=", 1)
            elif ":" in line:
                key, value = line.split(":", 1)
            else:
                continue

            result[key.strip().lower()] = value.strip()

    return result


class SummaryModule(BaseModule):
    name = "Summary"
    VERSION = UST_QC_BUILD_LABEL
    PRODUCT_NAME = "UST QC"

    timestamp_paths = [
        "tool/timestamp",
        "main_sensor/timestamp",
        "secondary_sensors/PT/timestamp",
        "secondary_sensors/TOF/timestamp",
    ]

    CONFIDENCE_COLORS = {
        "PASS": "#6aa56a",
        "WARN": "#c8a93d",
        "FAIL": "#c85b5b",
    }

    RADAR_BAND_RED = "#f6d6d6"
    RADAR_BAND_YELLOW = "#f4ebbf"
    RADAR_BAND_GREEN = "#d8ead8"

    def _parse_iso(self, value):
        if value is None:
            return None
        if isinstance(value, bytes):
            value = value.decode("utf-8", errors="ignore")
        text = str(value).strip()
        if not text:
            return None
        try:
            if text.endswith("Z"):
                return datetime.fromisoformat(text.replace("Z", "+00:00"))
            return datetime.fromisoformat(text)
        except Exception:
            return None

    def _parse_offset(self, value):
        if value is None:
            return None
        if isinstance(value, bytes):
            value = value.decode("utf-8", errors="ignore")
        text = str(value).strip()
        if not text:
            return None
        sign = -1 if text.startswith("-") else 1
        clean = text.lstrip("+-")
        parts = clean.split(":")
        try:
            hh = int(parts[0]) if len(parts) >= 1 else 0
            mm = int(parts[1]) if len(parts) >= 2 else 0
            ss = int(parts[2]) if len(parts) >= 3 else 0
            return timezone(sign * timedelta(hours=hh, minutes=mm, seconds=ss))
        except Exception:
            return None

    def _find_time_series(self, h5):
        for path in self.timestamp_paths:
            if has_dataset(h5, path):
                arr = to_float_array(get_dataset(h5, path)).reshape(-1)
                arr = arr[np.isfinite(arr)]
                if arr.size:
                    return path, arr
        return None, np.array([], dtype=float)

    def _fmt_dt(self, dt):
        if dt is None:
            return "n/a"
        return dt.strftime("%Y-%m-%d %H:%M:%S")

    def _load_sidecar_config(self, h5):
        h5_path = getattr(h5, "filename", "")
        if not h5_path:
            return {}
        cfg_path = os.path.join(os.path.dirname(os.path.abspath(h5_path)), "config.txt")
        if not os.path.exists(cfg_path):
            return {}
        try:
            return _parse_config_txt(cfg_path)
        except Exception:
            return {}

    def _job_value(self, h5, key):
        sidecar = self._load_sidecar_config(h5)
        val = sidecar.get(key.lower(), "").strip()
        if val:
            return val
        try:
            attrs = h5["config/JOB"].attrs
            for k in attrs.keys():
                if str(k).lower() == key.lower():
                    out = attrs.get(k)
                    if isinstance(out, bytes):
                        out = out.decode("utf-8", errors="ignore")
                    out = str(out).strip()
                    if out:
                        return out
        except Exception:
            pass
        return ""

    def _default_confidence_payload(self):
        return {
            "overall": 0.0,
            "status": "FAIL",
            "axes": {
                "Echo Lvl": 0.0,
                "Coverage": 0.0,
                "Cent": 0.0,
                "Stability": 0.0,
                "SoS": 0.0,
                "P/T": 0.0,
            },
        }

    def _normalize_confidence_payload(self, payload):
        if not isinstance(payload, dict):
            return self._default_confidence_payload()

        overall = payload.get("overall", payload.get("score", 0.0))
        try:
            overall = float(overall)
        except Exception:
            overall = 0.0

        status = payload.get("status")
        band = payload.get("band")

        if not status:
            if isinstance(band, str):
                band_upper = band.strip().upper()
                if band_upper in ("PASS", "WARN", "FAIL"):
                    status = band_upper
                elif band_upper == "GREEN":
                    status = "PASS"
                elif band_upper in ("YELLOW", "AMBER"):
                    status = "WARN"
                else:
                    status = "FAIL"
            else:
                if overall > 75.0:
                    status = "PASS"
                elif overall >= 40.0:
                    status = "WARN"
                else:
                    status = "FAIL"

        axes = payload.get("axes", {})
        normalized_axes = {
            "Echo Lvl": float(axes.get("Echo Lvl", axes.get("EchoLvl", axes.get("Echo", 0.0)))),
            "Coverage": float(axes.get("Coverage", axes.get("coverage", 0.0))),
            "Cent": float(axes.get("Cent", axes.get("cent", axes.get("centralization", 0.0)))),
            "Stability": float(axes.get("Stability", axes.get("stability", 0.0))),
            "SoS": float(axes.get("SoS", axes.get("sos", 0.0))),
            "P/T": float(axes.get("P/T", axes.get("pt", 0.0))),
        }

        return {
            "overall": float(np.clip(overall, 0.0, 100.0)),
            "status": status,
            "axes": axes,
            "normalized_axes": normalized_axes,
        }

    def compute(self, h5):
        display_name = (
            self._job_value(h5, "well")
            or self._job_value(h5, "job_description")
            or self._job_value(h5, "well_id")
            or os.path.basename(getattr(h5, "filename", "imported_file.h5"))
        )

        boot_dt = None
        try:
            boot_dt = self._parse_iso(h5["job"].attrs.get("boot_datetime"))
        except Exception:
            boot_dt = None

        try:
            arm_dt = self._parse_iso(h5["job"].attrs.get("arm_datetime"))
        except Exception:
            arm_dt = None

        try:
            creation_date = self._parse_iso(h5.attrs.get("Creation Date"))
        except Exception:
            creation_date = None

        try:
            local_tz = self._parse_offset(self._job_value(h5, "localtime_offset"))
        except Exception:
            local_tz = None

        ts_path, ts = self._find_time_series(h5)
        start_dt = end_dt = None
        if ts.size and boot_dt is not None:
            start_dt = boot_dt + timedelta(seconds=float(np.nanmin(ts)))
            end_dt = boot_dt + timedelta(seconds=float(np.nanmax(ts)))
        elif arm_dt is not None:
            start_dt = arm_dt
            end_dt = creation_date or arm_dt
        elif creation_date is not None:
            start_dt = creation_date
            end_dt = creation_date

        if local_tz is not None:
            if start_dt is not None and start_dt.tzinfo is not None:
                start_dt = start_dt.astimezone(local_tz)
            if end_dt is not None and end_dt.tzinfo is not None:
                end_dt = end_dt.astimezone(local_tz)

        duration_s = (end_dt - start_dt).total_seconds() if (start_dt is not None and end_dt is not None) else float("nan")
        minutes = duration_s / 60.0 if np.isfinite(duration_s) else float("nan")
        duration_text = f"{minutes:.1f} min" if np.isfinite(minutes) else "n/a"

        disclaimer = "Best estimate assumptions are made but do not guarantee accuracy."
        contact = "Issues/comments? Email to info@Fusiondownhole.com"

        raw_confidence = compute_confidence(h5)
        confidence = self._normalize_confidence_payload(raw_confidence)

        confidence_line = f"Overall confidence in acquired data is {confidence['overall']:.1f}%."
        timing_line = f"Start Time: {self._fmt_dt(start_dt)} | Duration: {duration_text}"

        return ModuleResult(
            name=self.name,
            status="INFO",
            messages=[
                f"Primary time source: {ts_path}" if ts_path else "Primary time source unavailable",
                confidence_line,
            ],
            metrics={
                "PASS": ("", "PASS", ""),
                "WARN": ("", "WARN", ""),
                "FAIL": ("", "FAIL", ""),
                "ERROR": ("", "ERROR", ""),
                "INFO": ("", "INFO", ""),
            },
            plot_data={
                "display_name": display_name,
                "header_text": f"{self.PRODUCT_NAME} {self.VERSION}",
                "line1": "Automated QC summary and analysis for:",
                "timing_line": timing_line,
                "disclaimer": disclaimer,
                "contact": contact,
                "confidence_line": confidence_line,
                "confidence": confidence,
                "logo_path": os.fspath(resource_path("assets", "logo_id_1.png")),
            },
        )

    def _render_spider_to_png(self, confidence):
        axes_dict = confidence.get("normalized_axes", {})
        labels = list(axes_dict.keys())
        values = [float(axes_dict[k]) for k in labels]

        if not labels:
            labels = ["Echo Lvl", "Coverage", "Cent", "Stability", "SoS", "P/T"]
            values = [0, 0, 0, 0, 0, 0]

        n = len(labels)
        angles = np.linspace(0.0, 2.0 * np.pi, n, endpoint=False).tolist()
        angles_closed = angles + angles[:1]
        values_closed = values + values[:1]

        spider_fig = plt.figure(figsize=(3.6, 3.6), facecolor="white")
        ax = spider_fig.add_axes([0.06, 0.06, 0.88, 0.88], polar=True)

        ax.set_theta_offset(np.pi / 2.0)
        ax.set_theta_direction(-1)
        ax.set_ylim(0.0, 100.0)
        ax.set_facecolor("white")

        theta_full = np.linspace(0.0, 2.0 * np.pi, 720)

        ax.fill_between(theta_full, 0, 40, color=self.RADAR_BAND_RED, alpha=0.45, zorder=0)
        ax.fill_between(theta_full, 40, 75, color=self.RADAR_BAND_YELLOW, alpha=0.55, zorder=0)
        ax.fill_between(theta_full, 75, 100, color=self.RADAR_BAND_GREEN, alpha=0.55, zorder=0)

        ax.set_xticks(angles)
        xt = ax.set_xticklabels(labels, fontsize=8.8, color="#374151")
        for t in xt:
            t.set_clip_on(False)

        ax.tick_params(axis="x", pad=10)
        ax.set_yticks([20, 40, 75, 100])
        ax.set_yticklabels([])
        ax.grid(color="#d1d5db", linewidth=0.8)
        ax.spines["polar"].set_color("#c7ccd3")
        ax.spines["polar"].set_linewidth(1.0)

        ax.plot(angles_closed, values_closed, color="#4f6f96", linewidth=2.0, zorder=3)
        ax.fill(angles_closed, values_closed, color="#7fa4c6", alpha=0.28, zorder=2)

        overall = float(confidence.get("overall", 0.0))
        status = confidence.get("status", "FAIL")
        center_color = self.CONFIDENCE_COLORS.get(status, "#6b7280")

        badge = Circle(
            (0.5, 0.5),
            0.215,
            transform=ax.transAxes,
            facecolor="white",
            edgecolor="#9ca3af",
            linewidth=1.8,
            zorder=4,
        )
        ax.add_patch(badge)

        ax.text(
            0.512,
            0.488,
            f"{overall:.0f}",
            transform=ax.transAxes,
            ha="center",
            va="center",
            fontsize=38,
            fontweight="bold",
            color="#475569",
            alpha=0.20,
            zorder=4.6,
        )

        ax.text(
            0.5,
            0.5,
            f"{overall:.0f}",
            transform=ax.transAxes,
            ha="center",
            va="center",
            fontsize=36,
            fontweight="bold",
            color=center_color,
            zorder=5,
        )

        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".png")
        tmp.close()
        spider_fig.savefig(
            tmp.name,
            dpi=240,
            facecolor="white",
            bbox_inches="tight",
            pad_inches=0.06,
        )
        plt.close(spider_fig)
        return tmp.name

    def draw(self, fig, left, bottom, width, height, result: ModuleResult):
        header_h = height * 0.10
        plot_zone_h = height * 0.55
        xband_h = height * 0.05
        box_zone_h = height * 0.30

        pad_left = width * 0.12
        pad_right = width * 0.12
        inner_left = left + pad_left
        inner_width = width - pad_left - pad_right
        title_y = bottom + height - header_h * 0.58

        logo_path = result.plot_data.get("logo_path")
        if logo_path and os.path.exists(logo_path):
            try:
                img = imread(logo_path)
                logo_h = header_h * 1.17
                logo_w = min(inner_width * 0.60, logo_h * 6.2)
                logo_bottom = title_y - logo_h / 2
                lax = fig.add_axes([inner_left, logo_bottom, logo_w, logo_h], anchor="W")
                lax.imshow(img)
                lax.set_axis_off()
            except Exception:
                fig.text(
                    inner_left,
                    title_y,
                    "Fusion Downhole",
                    fontsize=16,
                    fontweight="bold",
                    ha="left",
                    va="center",
                    color="#0b224f",
                )
        else:
            fig.text(
                inner_left,
                title_y,
                "Fusion Downhole",
                fontsize=16,
                fontweight="bold",
                ha="left",
                va="center",
                color="#0b224f",
            )

        fig.text(
            inner_left + inner_width,
            title_y,
            result.plot_data.get("header_text", ""),
            fontsize=10.5,
            ha="right",
            va="center",
            color="#4b5563",
        )

        content_bottom = bottom + box_zone_h + xband_h + height * 0.02
        content_h = plot_zone_h - height * 0.02

        spider_w = inner_width * 0.285
        gap_w = inner_width * 0.045
        text_w = inner_width - spider_w - gap_w

        spider_left = inner_left + inner_width * 0.010
        spider_bottom = content_bottom - content_h * 0.045
        spider_h = content_h * 0.94

        spider_png = None
        try:
            spider_png = self._render_spider_to_png(
                result.plot_data.get("confidence", self._default_confidence_payload())
            )
            spider_img = imread(spider_png)
            sax = fig.add_axes([spider_left, spider_bottom, spider_w, spider_h])
            sax.imshow(spider_img)
            sax.set_axis_off()
        finally:
            if spider_png and os.path.exists(spider_png):
                try:
                    os.remove(spider_png)
                except Exception:
                    pass

        text_left = spider_left + spider_w + gap_w
        ax = fig.add_axes([text_left, content_bottom, text_w, content_h], facecolor="white")
        ax.set_axis_off()

        x_right = 0.995

        ax.text(
            x_right,
            0.79,
            result.plot_data.get("line1", ""),
            ha="right",
            va="center",
            fontsize=10.8,
            color="#374151",
            wrap=False,
        )
        ax.text(
            x_right,
            0.61,
            result.plot_data.get("display_name", "Imported Job"),
            ha="right",
            va="center",
            fontsize=14.2,
            color="#111827",
            wrap=False,
        )
        ax.text(
            x_right,
            0.43,
            result.plot_data.get("confidence_line", ""),
            ha="right",
            va="center",
            fontsize=10.1,
            color="#374151",
            wrap=False,
        )
        ax.text(
            x_right,
            0.26,
            result.plot_data.get("timing_line", ""),
            ha="right",
            va="center",
            fontsize=9.6,
            color="#374151",
            wrap=False,
        )
        ax.text(
            x_right,
            0.16,
            result.plot_data.get("disclaimer", ""),
            ha="right",
            va="center",
            fontsize=8.7,
            color="#374151",
            wrap=False,
        )
        ax.text(
            x_right,
            -0.03,
            result.plot_data.get("contact", ""),
            ha="right",
            va="bottom",
            fontsize=8.8,
            color="#1d4ed8",
            url="mailto:info@Fusiondownhole.com",
        )

        labels = list(result.metrics.keys())
        boxes_bottom = bottom + height * 0.05
        boxes_h = box_zone_h - height * 0.11

        draw_status_row(
            fig,
            left=inner_left,
            bottom=boxes_bottom,
            width=inner_width,
            height=boxes_h,
            labels=labels,
            gap_fraction=0.014,
            edgecolor="#9aa0a6",
            linewidth=1.0,
            font_size=10.0,
            font_weight="bold",
            text_color="#1f2937",
            marker_radius=0.020,
        )
